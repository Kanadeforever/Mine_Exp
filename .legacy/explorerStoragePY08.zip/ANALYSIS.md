# ExplorerSessionSaver 项目分析文档

> **版本**: PyQt6 重构版（原始 AHK 脚本转写）  
> **用途**: 保存与恢复 Windows 资源管理器（Explorer）窗口状态的桌面工具  
> **源码位置**: `c:\Users\kaya\Desktop\explorerStorage`

---

## 目录

1. [项目概述](#1-项目概述)
2. [项目结构](#2-项目结构)
3. [架构设计](#3-架构设计)
4. [模块详解](#4-模块详解)
5. [已完成改进](#5-已完成改进)
6. [待改进清单](#6-待改进清单)
7. [开发指南](#7-开发指南)
8. [打包与分发](#8-打包与分发)

---

## 1. 项目概述

### 1.1 功能

- **保存会话**: 将当前所有打开的资源管理器窗口的路径和位置保存为 JSON 文件
- **恢复会话**: 根据保存的会话文件重新打开资源管理器窗口并设置位置
- **快速恢复**: 通过全局热键直接恢复最新保存的会话
- **会话管理**: 查看、删除已保存的会话
- **系统托盘**: 最小化到系统托盘，支持托盘菜单
- **多语言**: 支持中/英文界面（可扩展）

### 1.2 技术栈

| 技术 | 版本 | 用途 |
|------|------|------|
| Python | 3.13 | 主开发语言 |
| PyQt6 | ≥6.5 | GUI 框架 |
| pywin32 | ≥311 | Windows COM 接口操作 Explorer |
| PyInstaller | 6.20 | 打包为单文件 exe |

### 1.3 开发环境

- **虚拟环境**: `venv\`（已配置）
- **IDE**: VS Code

---

## 2. 项目结构

```
explorerStorage/
├── main.py                  # 入口点
├── config.ini               # 用户配置（语言、热键）
├── requirements.txt         # Python 依赖
├── build.bat                # PyInstaller 打包脚本
├── run.bat                  # 开发运行脚本
│
├── app/
│   ├── __init__.py
│   ├── main_window.py       # 主窗口 + 系统托盘 + 热键注册
│   ├── config_manager.py    # 配置/INI 读写 + 资源释放
│   ├── session_manager.py   # 会话核心逻辑（COM 操作 Explorer）
│   ├── settings_dialog.py   # 设置对话框（语言/热键）
│   ├── manage_dialog.py     # 会话管理对话框
│   ├── hotkey_manager.py    # Win32 全局热键封装
│   ├── language_manager.py  # 多语言翻译加载
│   └── resources/           # 图标等静态资源
│       └── icon.png
│
├── language/
│   ├── zh_CN.ini            # 中文翻译
│   └── en_US.ini            # 英文翻译
│
└── Session/                 # 会话 JSON 存储目录
```

---

## 3. 架构设计

### 3.1 分层架构

```
┌─────────────────────────────────────────┐
│            main.py (入口)               │
│  - 创建 QApplication                    │
│  - 初始化 MainWindow                    │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│     app/main_window.py (主窗口)         │
│  - UI 布局                              │
│  - 系统托盘                             │
│  - 热键注册 & 事件过滤                   │
│  - 操作编排（保存/恢复/管理）             │
└───┬───────┬───────┬────────┬────────────┘
    │       │       │        │
    ▼       ▼       ▼        ▼
  config_  session_  settings_  manage_
  manager  manager   dialog    dialog
  .py      .py       .py       .py
    │       │
    │       └── win32com → Shell.Application → COM → Explorer
    │
    └── configparser → config.ini / language/*.ini
```

### 3.2 数据流

**保存流程**:
```
用户点击"保存" / 热键 Ctrl+Shift+S
        │
        ▼
session_manager.get_open_windows()
        │  → Shell.Application.Windows()
        │  → 遍历每个窗口获取 Path, Left, Top, Width, Height
        ▼
session_manager.save_session(name)
        │  → json.dumps() → Session/2026-05-08_*.json
        ▼
状态栏/托盘显示"已保存"
```

**恢复流程**:
```
用户选择会话 / 热键 Ctrl+Shift+R
        │
        ▼
session_manager.restore_session(name, progress_callback)
        │  → json.loads() 读取会话文件
        │  → 遍历每个窗口:
        │    1. shell.Open(path) 打开文件夹
        │    2. _wait_for_window_hwnd() 轮询检测窗口 HWND
        │    3. SetWindowPos() 设置窗口位置
        ▼
状态栏/托盘显示"已恢复 N 个窗口"
```

---

## 4. 模块详解

### 4.1 `app/config_manager.py` — 配置管理

**职责**:
- 读取/写入 `config.ini`
- 读取 INI 格式的语言文件
- Frozen 模式启动时自动释放内置资源（`init_resources()`）

**关键类/函数**:

| 名称 | 说明 |
|------|------|
| `get_base_dir()` | 获取程序根目录（兼容脚本与 PyInstaller） |
| `init_resources()` | 首次运行时从 exe 内释放 `language/` 和 `resources/` 到程序目录 |
| `_IniParser` | `ConfigParser` 子类，保留 option key 原始大小写（修复 key 转小写 bug） |
| `read_ini()` | 通用 INI 文件读取，返回 `{section: {key: value}}` |
| `load_config()` | 加载 `config.ini`，合并默认值 |
| `save_config()` | 保存配置到 `config.ini` |

**改进亮点**:
- 新增 `_IniParser` 解决 `configparser` 默认将所有 key 转小写的坑（`SaveBtn` → `savebtn`）
- 新增 `init_resources()` 解决 PyInstaller 单文件模式 `language/` 不可见的问题
- 引入 `get_logger()` 统一日志输出
- 引入 `ConfigError` 等自定义异常细化错误类型

### 4.2 `app/session_manager.py` — 会话核心逻辑

**职责**:
- 通过 win32com 的 `Shell.Application` COM 接口操作 Windows Explorer
- 完全替代了原始项目中的 5 个 PowerShell 脚本

**关键函数**:

| 函数 | 对应原脚本 | 说明 |
|------|-----------|------|
| `get_open_windows()` | `Get-ExplorerSessions.ps1` | 获取所有 Explorer 窗口信息 |
| `save_session(name)` | `Save-Session.ps1` | 保存当前状态到 JSON |
| `restore_session(name, progress_callback)` | `Restore-Session.ps1` | 从 JSON 恢复窗口（异步友好） |
| `_wait_for_window_hwnd(shell, path, timeout)` | — | 轮询检测窗口 HWND（替代 sleep） |
| `list_sessions()` | `List-Sessions.ps1` | 列出已保存会话 |
| `delete_session(name)` | `Delete-Session.ps1` | 删除指定会话 |
| `rename_session(old, new)` | — | 重命名会话 |
| `get_latest_session_name()` | — | 获取最新会话名称 |
| `session_exists(name)` | — | 检查会话是否存在 |
| `generate_session_name()` | — | 生成时间戳文件名 |

**COM 接口说明**:
- `Shell.Application.Windows()` — 枚举所有 Explorer 窗口
- `window.Document.Folder.Self.Path` — 获取窗口当前路径
- `shell.Open(path)` — 打开一个新 Explorer 窗口
- `window.HWND` — 获取窗口句柄，配合 `SetWindowPos()` 设置位置

### 4.3 `app/hotkey_manager.py` — 全局热键

**职责**:
- 封装 Win32 `RegisterHotKey` / `UnregisterHotKey` API
- 通过 `QAbstractNativeEventFilter` 接收 WM_HOTKEY 消息

**关键类**:

| 类 | 说明 |
|------|------|
| `HotkeyManager` | 热键注册、注销、分发 |
| `WinHotkeyFilter` | PyQt6 原生事件过滤器，将 Win32 消息桥接到 Qt 事件循环 |

**热键格式**: `Ctrl+Shift+S`, `Alt+F1`, `Win+E` 等  
**支持的修饰键**: `Ctrl`, `Shift`, `Alt`, `Win`  
**支持的按键**: A-Z, 0-9, F1-F12, Space, Enter, Escape, Tab, 方向键等

### 4.4 `app/language_manager.py` — 多语言

**职责**:
- 加载 INI 格式翻译文件
- 提供 `t(module, key, *args)` 方法获取翻译文本
- 支持 `%1`, `%2` 参数占位符

**翻译文件格式**（实际包含 8 个 section，共 107 行）:
```ini
[TrayMenu]
SaveSession=保存当前会话
QuickRestore=快速恢复（最新）
...
[Main]
Title=资源管理器会话保存器
SaveBtn=保存当前会话
Saved=已保存会话 %1（%2 个窗口）
[Tray]
Tooltip=资源管理器会话保存器
Save=保存当前会话
```

> 完整翻译文件见 `language/zh_CN.ini`（中文）和 `language/en_US.ini`（英文），涵盖 `TrayMenu`、`Save`、`Restore`、`CurrentWindows`、`ManageSessions`、`General`、`Settings`、`Main`、`Tray` 共 9 个 section。

### 4.5 `app/main_window.py` — 主窗口

**职责**:
- 工具栏风格 UI（5 个按钮 + 状态栏）
- 系统托盘（右键菜单 + 双击显示）
- 全局热键的注册与事件过滤
- 关闭窗口时隐藏到托盘（`closeEvent`）
- 异步恢复（`RestoreWorker` + `QProgressDialog`）

**注意**:
- 窗口默认隐藏（启动后只显示托盘图标），如需显示窗口可取消 `main.py` 第 34 行的注释
- 热键过滤器需要管理员权限才能正常工作（非管理员时状态栏会提示）
- `RestoreWorker` 工作线程发出 `progress` 信号，主线程更新进度对话框

### 4.6 `app/settings_dialog.py` — 设置对话框

**职责**:
- 语言选择（自动扫描 `language/*.ini` 文件）
- 热键设置（`HotkeyLineEdit` 自定义捕获控件）
- 保存设置后提示重启

**`HotkeyLineEdit` 实现**:
- 继承 `QLineEdit`，`focusInEvent` 启动捕获模式
- `keyPressEvent` 检测修饰键 + 普通键组合
- 显示为 `Ctrl+Shift+S` 格式

### 4.7 `app/manage_dialog.py` — 会话管理

**职责**:
- 列表展示已保存会话（名称 + 窗口数 + 时间）
- **多选**删除/恢复会话
- **重命名**会话（F2 快捷键）
- **打开保存路径**文件夹
- 键盘快捷键：Delete（删除）、Enter（恢复）、F2（重命名）、Ctrl+A（全选）
- 使用 `QListWidgetItem.setData()` 存储会话名，避免从显示字符串解析的歧义
- 多选删除时显示 "N items selected" 确认提示

---

## 5. 已完成改进

### 5.1 Bug 修复

| # | 问题 | 修复 | 文件 |
|---|------|------|------|
| 1 | `configparser` 将 `SaveBtn` 转为 `savebtn` 导致翻译查找失败 | 新增 `_IniParser` 重写 `optionxform` | `config_manager.py` |
| 2 | PyInstaller 单文件模式下 `language/` 目录不可见 | 新增 `init_resources()` 启动时释放 | `config_manager.py` |
| 3 | 图标资源在单文件模式下不可见 | `init_resources()` 一并释放 `resources/` | `config_manager.py` |
| 4 | `main_window.py` 中冗余的 `sys._MEIPASS` 图标回退路径 | 移除，统一由 `init_resources()` 处理 | `main_window.py` |
| 5 | `run.bat` 调用不存在的 `main.pyw` | 改为 `python main.py` | `run.bat` |
| 6 | 日志系统缺失，异常被静默忽略 | 新建 `app/logger.py`，所有模块集成 `get_logger()` | `logger.py` + 各模块 |
| 7 | 异常处理粒度过粗，多处 `except: pass` | 引入自定义异常（`SessionError`、`HotkeyError`、`ConfigError`），区分预期/非预期异常 | 各模块 |
| 8 | 会话列表用 `split(" | ")` 提取名称，显示字符串变更时易出错 | 改为 `QListWidgetItem.setData(Qt.UserRole, name)` 存储 | `manage_dialog.py` |
| 9 | 缺少会话重命名功能 | 新增重命名按钮 + F2 快捷键 + `rename_session()` API | `manage_dialog.py` + `session_manager.py` |
| 10 | **P0** 恢复位置不稳定，`sleep(0.3)` 硬等待 | 新增 `_wait_for_window_hwnd()` 轮询检测窗口创建 | `session_manager.py` |
| 11 | **P0** 热键注册失败被静默忽略 | try/except 捕获异常，日志记录，状态栏提示 | `main_window.py` |
| 12 | **P1** 恢复时没有进度反馈，界面卡住 | `RestoreWorker` (QThread) 异步 + `QProgressDialog` 进度显示 + 可取消 | `main_window.py` + `session_manager.py` |

### 5.2 架构优化

- PowerShell 脚本 → 纯 Python（win32com），消除了对 PowerShell 执行环境的依赖
- 全局常量和路径集中到 `config_manager.py` 管理
- 热键管理抽象为独立模块 `hotkey_manager.py`
- 支持多语言（中/英），翻译文件格式简单，便于社区贡献

---

## 6. 待改进清单

按优先级从高到低排列：

### 🔴 P0 — 影响核心功能

#### 6.1 ~~`restore_session()` 位置恢复不稳定~~ ✅ **已修复**

- **修复**: `session_manager.py` 新增 `_wait_for_window_hwnd()`，轮询检测窗口 HWND 出现（对比路径），超时 5 秒，替代固定 `sleep(0.3)`
- **提交**: 2026-05-08

#### 6.2 ~~热键在非管理员权限下可能失效~~ ✅ **已修复**

- **修复**: `main_window.py` 热键注册时 try/except 捕获异常，记录日志，状态栏显示 `HotkeyError` / `HotkeyFilterFailed` 翻译文本
- **提交**: 2026-05-08

### 🟠 P1 — 重要但不阻塞核心功能

#### 6.3 ~~恢复时没有进度反馈~~ ✅ **已修复**

- **修复**: 
  - 新增 `RestoreWorker(QThread)` 异步执行恢复
  - `QProgressDialog` 实时显示进度（"正在恢复：路径名"）
  - 恢复过程中允许用户点击"取消"中断
  - `restore_session()` 新增 `progress_callback` 参数
- **提交**: 2026-05-08

### 🟡 P2 — 体验优化

#### 6.6 ~~配置修改后无需重启即可生效~~ ✅ **已修复**

- **位置**: `main_window.py`
- **修复**: 
  - `SettingsDialog` 保存后检测语言变更 → 运行时重新创建 `LanguageManager` 并刷新所有 UI 文本（窗口标题、按钮、托盘菜单、状态栏）
  - 保存后检测热键变更 → `_reload_hotkeys()` 先 `unregister_all()` 再重新注册
  - 状态栏提示"设置已保存"而非"请重启"
  - 设置对话框提示改为"语言和热键更改将立即生效"
- **提交**: 2026-05-08

#### 6.7 ~~托盘图标缺失~~ ✅ **已修复**

- **位置**: `app/resources/icon.png`
- **修复**: 已提供 `app/resources/icon.png` 图标文件，主窗口 `setup_tray()` 优先加载该图标，不存在时优雅回退到 Qt 内置图标
- **提交**: 2026-05-08

#### 6.8 ~~响应式 UI 不够友好~~ ✅ **已修复**

- **位置**: `main_window.py`
- **修复**:
  - 新增 `setup_window_shortcuts()`：`Alt+S` 保存、`Alt+R` 恢复、`Alt+M` 管理、`Alt+T` 设置、`Alt+Q` 退出
  - 默认最小尺寸从 400×300 缩小为 300×250
- **提交**: 2026-05-08

#### 6.9 ~~启动时不显示窗口，用户可能以为没启动~~ ✅ **已修复**

- **位置**: `main_window.py`
- **修复**: 启动延迟 1.5 秒后在托盘显示通知气泡，提示程序已在运行
- **提交**: 2026-05-08

### 🔵 P3 — 代码质量 / 工程化

#### 6.10 ~~`COM` 初始化未正确清理~~ ✅ **已修复**

- **位置**: `session_manager.py`
- **修复**: 
  - 新增 `_com_context()` 上下文管理器，自动配对 `CoInitialize()` / `CoUninitialize()`
  - `_get_shell()` 和 `_wait_for_window_hwnd()` 均已改用 `with _com_context():` 包装
  - 同时保留了 `_init_com()` 兼容旧代码调用
- **提交**: 2026-05-08

#### 6.11 ~~`read_ini` 的编码兼容性~~ ✅ **已修复**

- **位置**: `config_manager.py`
- **修复**: 
  - 新增 `_detect_encoding(path)` 函数自动检测 BOM（支持 utf-8-sig / utf-16-le / utf-16-be / utf-8）
  - `read_ini()` 改为先检测编码再读取，兼容各种 BOM 变体
- **提交**: 2026-05-08

#### 6.12 ~~单元测试缺失~~ ✅ **已修复**

- **修复**: 
  - `tests/` 目录已创建，包含 **36 项测试用例**（4 个测试文件 + `conftest.py` 共享 fixture）
  - `test_config_manager.py` — 配置读写逻辑测试（11 项）
  - `test_hotkey_manager.py` — 热键解析与验证测试（7 项）
  - `test_language_manager.py` — 翻译加载与查找测试（6 项）
  - `test_session_manager.py` — JSON 读写、列表排序、重命名测试（12 项）
  - `conftest.py` 提供 `session_dir` fixture 隔离会话目录，避免污染真实数据
  - 详情见 `tests/README.md`
- **提交**: 2026-05-08

#### 6.14 ~~类型提示不完善~~ ✅ **已修复**

- **修复**: 所有公开函数已添加完整类型注解（`list[dict]`、`str | None`、`Callable` 等），模块接口清晰可读
- **提交**: 2026-05-08

#### 6.15 ~~没有版本号~~ ✅ **已修复**

- **修复**: `app/__init__.py` 已定义 `__version__ = "1.0.0"`
- **提交**: 2026-05-08

#### 6.16 ~~配置文件格式改进~~ ✅ **已评估，无需修改**

- **评估结论**: 当前 INI + `_IniParser`（保留 key 大小写）+ `_detect_encoding()`（BOM 兼容）方案已稳定通过测试，无实际缺陷
- **理由**:
  - 改用 `QSettings` 有 Windows 注册表依赖风险，且无法热加载 `.ini` 语言文件
  - 改用 TOML 需引入 `tomli-w` 写文件，增加依赖
  - 当前方案约 80 行代码，功能完整，测试覆盖
  - **不迁移，保持现状**
- **提交**: 2026-05-08

#### 6.17 ~~`build.bat` 中 `Session` 目录的创建~~ ✅ **已修复**

- **修复**: `config_manager.py:26` 使用 `SESSION_DIR.mkdir(parents=True, exist_ok=True)` 自动创建，模块加载即完成，无需打包脚本介入
- **提交**: 2026-05-08

#### 6.18 ~~依赖版本锁定~~ ✅ **已修复**

- **修复**: `requirements.txt` 已使用 `==` 精确锁定 `pywin32==311`、`PyQt6==6.11.0` 已验证版本
- **提交**: 2026-05-08

---

## 7. 开发指南

### 7.1 环境准备

```batch
# 激活虚拟环境
cd c:\Users\kaya\Desktop\explorerStorage
venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt
```

### 7.2 运行

```batch
python main.py
```

> 程序启动后默认只显示托盘图标（不显示主窗口）。双击托盘图标或右键菜单选择即可交互。

### 7.3 添加新语言

1. 在 `language/` 目录下创建 `xx_XX.ini`（例如 `ja_JP.ini`）
2. 参考 `zh_CN.ini` 的结构翻译所有字段
3. 运行程序，在设置中即可选择新语言

### 7.4 热键测试

```python
# 验证热键字符串是否合法
from app.hotkey_manager import HotkeyManager
assert HotkeyManager.validate("Ctrl+Shift+S") == True
assert HotkeyManager.validate("Alt+F4") == True
assert HotkeyManager.validate("Ctrl+InvalidKey") == False
```

### 7.5 会话数据格式

```json
[
    {
        "Path": "C:\\Users\\kaya\\Desktop",
        "Left": 100,
        "Top": 50,
        "Width": 1200,
        "Height": 800
    },
    ...
]
```

---

## 8. 打包与分发

### 8.1 单文件打包

```batch
build.bat
```

输出: `dist\ExplorerSessionSaver.exe` (约 38MB)

### 8.2 首次运行行为

- 自动在 exe 所在目录创建 `Session/` 和 `language/` 目录
- 从 exe 内部释放内置的翻译文件到 `language/`
- 从 exe 内部释放图标资源到 `app/resources/`
- 读取 `config.ini`（如不存在使用默认配置）

### 8.3 更新方式

- 替换 exe 文件即可
- 如果翻译文件有更新，删除 `language/` 目录后运行 exe 会自动重新释放
- `Session/` 中的历史会话文件不受影响

### 8.4 已知打包限制

- 打包后约 38MB（主要来自 PyQt6 和 pywin32）
- `--noconsole` 模式下无法看到控制台输出，调试需切回脚本模式
- 热键全局注册在打包后行为与脚本模式一致

---

## 附录

### A. 关于原始 AHK 脚本

原始 AHK 脚本 `ExplorerSessionSaver.ahk` 通过 PowerShell 脚本与 Windows COM 交互。PyQt6 版用 `win32com` 直接调用 `Shell.Application`，消除了对 PowerShell 的依赖，启动更快、更可靠。

### B. 用到的 Win32 API

| API | 用途 | 定义位置 |
|-----|------|---------|
| `RegisterHotKey` | 注册全局热键 | `hotkey_manager.py` |
| `UnregisterHotKey` | 注销全局热键 | `hotkey_manager.py` |
| `SetWindowPos` | 设置窗口位置和大小 | `session_manager.py` |

### C. 用到的 COM 接口

| 接口/对象 | 用途 | 调用位置 |
|-----------|------|---------|
| `Shell.Application` | 获取 COM 入口 | `session_manager.py:_get_shell()` |
| `IShellWindows` (Windows 集合) | 枚举所有 Explorer | `session_manager.py:get_open_windows()` |
| `IShellFolderView` (Document) | 获取窗口路径 | `session_manager.py:get_open_windows()` |
| `ShellWindows.Open()` | 打开新 Explorer 窗口 | `session_manager.py:restore_session()` |
| `IWebBrowser2.HWND` | 获取窗口 HWND | `session_manager.py:restore_session()` |