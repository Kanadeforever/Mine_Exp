"""
logger.py
日志系统：按启动时间戳生成日志文件到 BASE_DIR/logs/
P2-1: 支持多语言 key-based 日志，通过 LanguageManager 翻译后再写入
"""

import logging
import sys
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

from app.common import get_base_dir
from app.constants import LOG_DEFAULT_MAX_ENTRIES, LOG_MAX_ENTRIES_MIN, LOG_MAX_ENTRIES_MAX

BASE_DIR = get_base_dir()
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

_LOG_PREFIX = "explorerStorage-"
_LOG_GLOB_PATTERN = "explorerStorage-*.log"

# 日志格式
_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"
_DATE_FMT = "%Y-%m-%d %H:%M:%S"

# 全局 LanguageManager 引用（由 application 启动时设置）
_lang_mgr: Optional["LanguageManager"] = None  # noqa: F821

# 全局文件 handler 及状态
_file_handler: Optional[logging.FileHandler] = None
_log_enabled: bool = True
_max_entries: int = LOG_DEFAULT_MAX_ENTRIES

# ── 日志文件名正则（用于排序清理） ─────────────────────
_LOG_FILENAME_RE = re.compile(
    rf"^{re.escape(_LOG_PREFIX)}(\d{{4}}-\d{{2}}-\d{{2}}-\d{{2}}-\d{{2}}-\d{{2}})\.log$"
)


def set_language_manager(lm: "LanguageManager") -> None:  # noqa: F821
    """设置全局 LanguageManager 供日志翻译使用（P2-1）"""
    global _lang_mgr
    _lang_mgr = lm


def _t(key: str, *args) -> str:
    """通过 LanguageManager 翻译日志 key（如果已设置）"""
    if _lang_mgr is not None:
        try:
            return _lang_mgr.t("Logs", key, *args)
        except Exception:
            pass
    # fallback: 如果 key 没有翻译，直接格式化返回
    msg = key.replace("_", " ").capitalize()
    if args:
        msg = f"{msg}: {' '.join(str(a) for a in args)}"
    return msg


def log_debug(logger: logging.Logger, key: str, *args) -> None:
    """输出多语言 debug 级别日志（P2-1）"""
    logger.debug(_t(key, *args))


def log_info(logger: logging.Logger, key: str, *args) -> None:
    """输出多语言 info 级别日志（P2-1）"""
    logger.info(_t(key, *args))


def log_warning(logger: logging.Logger, key: str, *args) -> None:
    """输出多语言 warning 级别日志（P2-1）"""
    logger.warning(_t(key, *args))


def log_error(logger: logging.Logger, key: str, *args) -> None:
    """输出多语言 error 级别日志（P2-1）"""
    logger.error(_t(key, *args))


def get_logger(name: str) -> logging.Logger:
    """
    获取（或创建）一个按模块命名的 Logger。
    所有 Logger 共享一个文件 Handler，避免重复写入。
    """
    logger = logging.getLogger(name)
    if logger.handlers:  # 已有 Handler，直接返回
        return logger

    logger.setLevel(logging.DEBUG)

    # 使用共享的文件 Handler（如果已创建）
    if _file_handler is not None:
        logger.addHandler(_file_handler)

    # 控制台 Handler（仅在非打包模式输出）
    if not getattr(sys, 'frozen', False):
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(logging.Formatter(_FORMAT, _DATE_FMT))
        logger.addHandler(ch)

    return logger


def configure_logging(enabled: bool, max_entries: int) -> None:
    """
    运行时配置日志系统。
    - enabled: 是否启用日志文件输出
    - max_entries: 最多保留的日志文件数（>=5）
    """
    global _file_handler, _log_enabled, _max_entries

    _log_enabled = enabled
    _max_entries = max(max_entries, LOG_MAX_ENTRIES_MIN)

    if enabled:
        # 创建带时间戳的新日志文件
        timestamp = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
        log_file = LOG_DIR / f"{_LOG_PREFIX}{timestamp}.log"
        _file_handler = logging.FileHandler(log_file, encoding="utf-8", mode="a")
        _file_handler.setLevel(logging.DEBUG)
        _file_handler.setFormatter(logging.Formatter(_FORMAT, _DATE_FMT))

        # 将新 handler 添加到所有已存在的 Logger
        for logger_name in list(logging.Logger.manager.loggerDict.keys()):
            logger_obj = logging.Logger.manager.loggerDict[logger_name]
            if isinstance(logger_obj, logging.Logger):
                logger_obj.addHandler(_file_handler)
    else:
        # 禁用日志：从所有 Logger 中移除文件 Handler
        if _file_handler is not None:
            for logger_name in list(logging.Logger.manager.loggerDict.keys()):
                logger_obj = logging.Logger.manager.loggerDict[logger_name]
                if isinstance(logger_obj, logging.Logger):
                    logger_obj.removeHandler(_file_handler)
            _file_handler.close()
            _file_handler = None

    # 清理旧日志
    _cleanup_old_logs(_max_entries)


def _cleanup_old_logs(max_entries: int) -> None:
    """
    清理 logs/ 目录下超出 max_entries 数量的旧日志文件。
    文件名格式：explorerStorage-YYYY-MM-DD-HH-MM-SS.log
    按时间戳字符串升序排列，删除最旧的文件。
    """
    if not LOG_DIR.exists():
        return

    try:
        # 获取所有匹配的日志文件
        log_files: list[Path] = []
        for f in LOG_DIR.iterdir():
            if f.is_file() and _LOG_FILENAME_RE.match(f.name):
                log_files.append(f)

        # 按文件名（即按时间戳）升序排列，旧的在前面
        log_files.sort(key=lambda p: p.name)

        if len(log_files) <= max_entries:
            return

        # 删除超出数量的最旧文件
        to_delete = log_files[:len(log_files) - max_entries]
        for f in to_delete:
            try:
                f.unlink()
            except OSError:
                pass
    except Exception:
        pass


# ── 模块初始化：立即清理超出默认最大数量的旧日志 ──────
_cleanup_old_logs(LOG_DEFAULT_MAX_ENTRIES)