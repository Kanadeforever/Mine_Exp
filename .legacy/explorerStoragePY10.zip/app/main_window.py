"""
main_window.py
主窗口 + 系统托盘。实现所有用户交互逻辑。
"""

import sys
from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QSystemTrayIcon, QMenu,
    QMessageBox, QWidget, QVBoxLayout, QPushButton, QLabel,
    QHBoxLayout, QLineEdit, QListWidget, QInputDialog, QStyle,
    QProgressDialog,
)
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt6.QtGui import QIcon, QAction, QShortcut, QKeySequence

from app.language_manager import LanguageManager
from app import session_manager as sm
from app.settings_dialog import SettingsDialog
from app.manage_dialog import ManageDialog
from app.config_manager import load_config, save_config, BASE_DIR, LANGUAGE_DIR
from app.logger import get_logger, set_language_manager

logger = get_logger(__name__)

LANG_DIR = LANGUAGE_DIR
from app.hotkey_manager import (HotkeyManager, WinHotkeyFilter)


class RestoreWorker(QThread):
    """异步恢复工作线程（恢复整个会话）"""
    progress = pyqtSignal(int, int, str)  # success, failed, current_path
    finished = pyqtSignal(int, int)       # success, failed
    error = pyqtSignal(str)

    def __init__(self, session_name: str):
        super().__init__()
        self._name = session_name

    def run(self):
        try:
            succ, fail = sm.restore_session(
                self._name,
                progress_callback=lambda s, f, p: self.progress.emit(s, f, p)
            )
            self.finished.emit(succ, fail)
        except sm.SessionError as e:
            self.error.emit(str(e))
        except Exception as e:
            logger.exception("Restore worker error: %s", e)
            self.error.emit(str(e))


class RestorePartialWorker(QThread):
    """异步恢复工作线程（恢复会话中部分窗口）"""
    progress = pyqtSignal(int, int, str)  # success, failed, current_path
    finished = pyqtSignal(int, int)       # success, failed
    error = pyqtSignal(str)

    def __init__(self, session_name: str, indices: list[int]):
        super().__init__()
        self._name = session_name
        self._indices = indices

    def run(self):
        try:
            succ, fail = sm.restore_windows_from_session(
                self._name,
                self._indices,
                progress_callback=lambda s, f, p: self.progress.emit(s, f, p)
            )
            self.finished.emit(succ, fail)
        except sm.SessionError as e:
            self.error.emit(str(e))
        except Exception as e:
            logger.exception("Restore partial worker error: %s", e)
            self.error.emit(str(e))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # ── 配置和语言 ──
        self._cfg = load_config()
        self._lang_mgr = LanguageManager(LANG_DIR, self._cfg["Language"])
        self.setWindowTitle(self._lang_mgr.t("Main", "Title"))
        self._set_window_icon()

        # ── 注入 LanguageManager 到 logger（P2-1 日志多语言）──
        set_language_manager(self._lang_mgr)

        # ── UI ──
        self.setMinimumSize(300, 250)  # P2 6.8 缩小默认尺寸
        self.center_widget = QWidget()
        self.setCentralWidget(self.center_widget)
        self.setup_ui()
        self.setup_window_shortcuts()  # P2 6.8 窗口快捷键

        # ── 系统托盘 ──
        self.setup_tray()

        # ── 全局热键 ──
        self._hk_manager = HotkeyManager(int(self.winId()))
        self._hk_filter = WinHotkeyFilter(self._hk_manager)
        self._hook_hotkeys()

        # ── 安装原生事件过滤器 ──
        self._native_filter_installed = False
        QTimer.singleShot(0, self._install_native_filter)

        # ── 状态栏 ──
        self.statusBar().showMessage(self._lang_mgr.t("Main", "Ready"))

        # ── 启动通知（P2 6.9）──
        QTimer.singleShot(1500, self._show_startup_notification)

    # ── 窗口图标（P2-2）────────────────────────────────
    def _set_window_icon(self):
        icon_path = BASE_DIR / "app" / "resources" / "icon.png"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))

    # ── 窗口快捷键（P2 6.8）───────────────────────────
    def setup_window_shortcuts(self):
        QShortcut(QKeySequence("Alt+S"), self).activated.connect(self.save_session)
        QShortcut(QKeySequence("Alt+R"), self).activated.connect(self.do_quick_restore)
        QShortcut(QKeySequence("Alt+M"), self).activated.connect(self.manage_sessions)
        QShortcut(QKeySequence("Alt+T"), self).activated.connect(self.open_settings)
        QShortcut(QKeySequence("Alt+Q"), self).activated.connect(self.quit_app)

    # ── UI 布局 ───────────────────────────────────────
    def setup_ui(self):
        ly = QVBoxLayout(self.center_widget)
        ly.setContentsMargins(12, 12, 12, 12)
        ly.setSpacing(8)

        label = QLabel(self._lang_mgr.t("Main", "Hint"))
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ly.addWidget(label)

        self.save_btn = QPushButton(self._lang_mgr.t("Main", "SaveBtn"))
        self.save_btn.clicked.connect(self.save_session)
        ly.addWidget(self.save_btn)

        self.restore_btn = QPushButton(self._lang_mgr.t("Main", "RestoreLatestBtn"))
        self.restore_btn.clicked.connect(self.do_quick_restore)
        ly.addWidget(self.restore_btn)

        self.manage_btn = QPushButton(self._lang_mgr.t("Main", "ManageBtn"))
        self.manage_btn.clicked.connect(self.manage_sessions)
        ly.addWidget(self.manage_btn)

        self.settings_btn = QPushButton(self._lang_mgr.t("Main", "SettingsBtn"))
        self.settings_btn.clicked.connect(self.open_settings)
        ly.addWidget(self.settings_btn)

        self.quit_btn = QPushButton(self._lang_mgr.t("Main", "QuitBtn"))
        self.quit_btn.clicked.connect(self.quit_app)
        ly.addWidget(self.quit_btn)

        ly.addStretch()

    # ── 系统托盘 ───────────────────────────────────────
    def setup_tray(self):
        self.tray_icon = QSystemTrayIcon(self)
        icon_path = BASE_DIR / "app" / "resources" / "icon.png"
        if icon_path.exists():
            self.tray_icon.setIcon(QIcon(str(icon_path)))
        else:
            # fallback 到 Qt 内置图标
            self.tray_icon.setIcon(
                self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)
            )
        self.tray_icon.setToolTip(self._lang_mgr.t("Tray", "Tooltip") or "ExplorerSessionSaver")

        menu = QMenu()
        save_a = menu.addAction(self._lang_mgr.t("Tray", "Save"))
        save_a.triggered.connect(self.save_session)
        restore_a = menu.addAction(self._lang_mgr.t("Tray", "Restore"))
        restore_a.triggered.connect(self.restore_session)
        manage_a = menu.addAction(self._lang_mgr.t("Tray", "Manage"))
        manage_a.triggered.connect(self.manage_sessions)
        settings_a = menu.addAction(self._lang_mgr.t("Tray", "Settings"))
        settings_a.triggered.connect(self.open_settings)
        menu.addSeparator()
        quit_a = menu.addAction(self._lang_mgr.t("Tray", "Quit"))
        quit_a.triggered.connect(self.quit_app)
        self.tray_icon.setContextMenu(menu)
        self.tray_icon.show()

    # ── 全局热键 ───────────────────────────────────────
    def _hook_hotkeys(self):
        """注册热键并处理注册错误（P0 6.2）"""
        hotkeys = [
            ("SaveSession", self._cfg["SaveSession"], self.save_session),
            ("QuickRestore", self._cfg["QuickRestore"], self.do_quick_restore),
        ]
        errors = []
        for name, combo, callback in hotkeys:
            try:
                self._hk_manager.register(combo, callback)
                logger.info("Hotkey registered: %s = %s", name, combo)
            except Exception as e:
                errors.append(f"{name} ({combo}): {e}")
                logger.warning("Failed to register hotkey %s: %s", combo, e)

        if errors:
            msg = "; ".join(errors)
            self.statusBar().showMessage(
                self._lang_mgr.t("Main", "HotkeyError") % msg, 8000)

    def _install_native_filter(self):
        if not self._native_filter_installed:
            try:
                QApplication.instance().installNativeEventFilter(self._hk_filter)
                self._native_filter_installed = True
                logger.info("Native event filter installed")
            except Exception as e:
                msg = self._lang_mgr.t("Main", "HotkeyFilterFailed")
                self.statusBar().showMessage(msg)
                logger.warning("Failed to install native event filter: %s", e)

    def __del__(self):
        self._hk_manager.unregister_all()

    # ── 操作 ───────────────────────────────────────────
    def save_session(self):
        try:
            name = sm.generate_session_name()
            count = sm.save_session(name)
            msg = self._lang_mgr.t("Main", "Saved", name, str(count))
            self.statusBar().showMessage(msg, 5000)
            self.tray_icon.showMessage(
                self._lang_mgr.t("General", "Success"),
                msg,
                QSystemTrayIcon.MessageIcon.Information,
                3000)
            logger.info("Session saved: %s (%d windows)", name, count)
        except sm.SessionError as e:
            logger.error("Save session failed: %s", e)
            self.statusBar().showMessage(str(e), 5000)
        except Exception as e:
            logger.exception("Unexpected error saving session: %s", e)
            self.statusBar().showMessage(str(e), 5000)

    def do_quick_restore(self):
        """快速恢复（最新会话）"""
        name = sm.get_latest_session_name()
        if name is None:
            msg = self._lang_mgr.t("Main", "NoSessions")
            self.statusBar().showMessage(msg, 3000)
            self.tray_icon.showMessage(
                self._lang_mgr.t("General", "Info"),
                msg,
                QSystemTrayIcon.MessageIcon.Information,
                3000)
            return
        logger.info("Quick restore: %s", name)
        self._restore(name)

    def restore_session(self):
        """（保留供外部调用）恢复最新会话"""
        self.do_quick_restore()

    def restore_session_by_name(self, name: str):
        """按名称恢复会话（供 ManageDialog 调用）"""
        self._restore(name)
        # 让主窗口可见
        self.show()
        self.raise_()
        self.activateWindow()

    def restore_windows_by_indices(self, name: str, indices: list[int]):
        """按索引恢复会话中的部分窗口（供 ManageDialog 第二层调用）"""
        self._restore_partial(name, indices)

    def _restore_partial(self, name: str, indices: list[int]):
        """使用 QThread 异步恢复指定索引的窗口 + 进度对话框"""
        self.save_btn.setEnabled(False)
        self.restore_btn.setEnabled(False)
        self.manage_btn.setEnabled(False)

        progress = QProgressDialog(
            self._lang_mgr.t("Main", "RestoringProgress", name),
            self._lang_mgr.t("General", "Cancel"),
            0, 100, self)
        progress.setWindowTitle(self._lang_mgr.t("Main", "Restoring"))
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        progress.show()

        # 使用 RestorePartialWorker
        self._worker = RestorePartialWorker(name, indices)
        self._worker.progress.connect(
            lambda s, f, p: self._on_restore_progress(progress, s, f, p))
        self._worker.finished.connect(
            lambda s, f: self._on_restore_done(progress, name, s, f))
        self._worker.error.connect(
            lambda e: self._on_restore_error(progress, name, e))
        self._worker.finished.connect(self._worker.deleteLater)
        self._worker.error.connect(self._worker.deleteLater)
        progress.canceled.connect(self._on_restore_cancel)
        self._worker.start()

    def _restore(self, name: str):
        """
        使用 QThread 异步恢复 + 进度对话框（P1 6.3）。
        """
        # 禁用按钮防止重复操作
        self.save_btn.setEnabled(False)
        self.restore_btn.setEnabled(False)
        self.manage_btn.setEnabled(False)

        progress = QProgressDialog(
            self._lang_mgr.t("Main", "RestoringProgress", name),
            self._lang_mgr.t("General", "Cancel"),
            0, 100, self)
        progress.setWindowTitle(self._lang_mgr.t("Main", "Restoring"))
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        progress.show()

        # 启动工作线程
        self._worker = RestoreWorker(name)
        self._worker.progress.connect(
            lambda s, f, p: self._on_restore_progress(progress, s, f, p))
        self._worker.finished.connect(
            lambda s, f: self._on_restore_done(progress, name, s, f))
        self._worker.error.connect(
            lambda e: self._on_restore_error(progress, name, e))
        self._worker.finished.connect(self._worker.deleteLater)
        self._worker.error.connect(self._worker.deleteLater)
        progress.canceled.connect(self._on_restore_cancel)
        self._worker.start()

    def _on_restore_progress(self, progress: QProgressDialog, success: int, failed: int, status: str):
        progress.setLabelText(status)
        progress.setValue(success + failed)

    def _on_restore_cancel(self):
        if hasattr(self, '_worker') and self._worker.isRunning():
            self._worker.terminate()
            self._worker.wait()
            logger.info("Restore cancelled by user")
            self._reenable_buttons()

    def _on_restore_done(self, progress: QProgressDialog, name: str, success: int, failed: int):
        progress.close()
        msg = self._lang_mgr.t("Main", "Restored", str(success), str(failed))
        self.statusBar().showMessage(msg, 5000)
        self.tray_icon.showMessage(
            self._lang_mgr.t("General", "Success"),
            msg,
            QSystemTrayIcon.MessageIcon.Information,
            3000)
        logger.info("Restored %s: %d success, %d failed", name, success, failed)
        self._reenable_buttons()

    def _on_restore_error(self, progress: QProgressDialog, name: str, error_msg: str):
        progress.close()
        logger.error("Restore failed for %s: %s", name, error_msg)
        QMessageBox.warning(self, self._lang_mgr.t("General", "Error"), error_msg)
        self._reenable_buttons()

    def _reenable_buttons(self):
        self.save_btn.setEnabled(True)
        self.restore_btn.setEnabled(True)
        self.manage_btn.setEnabled(True)

    def manage_sessions(self):
        dlg = ManageDialog(self._lang_mgr, self)
        dlg.exec()
        # 恢复后刷新状态
        latest = sm.get_latest_session_name()
        if latest:
            self.statusBar().showMessage(
                self._lang_mgr.t("Main", "Ready"), 3000)

    # ── 设置（P2 6.6 配置热加载）───────────────────────
    def open_settings(self):
        dlg = SettingsDialog(self._cfg, self._lang_mgr, LANG_DIR, self)
        if dlg.exec() == SettingsDialog.DialogCode.Accepted:
            new_cfg = dlg.get_config()
            if new_cfg != self._cfg:
                old_lang = self._cfg["Language"]
                self._cfg = new_cfg
                save_config(self._cfg)

                # 语言变化 → 热切换（P2 6.6）
                if new_cfg["Language"] != old_lang:
                    self._reload_language()

                # 热键变化 → 重新注册（P2 6.6）
                self._reload_hotkeys()

                # 状态栏提示，无需重启
                self.statusBar().showMessage(
                    self._lang_mgr.t("Settings", "SavedMsg"), 3000)

    def _reload_language(self):
        """运行时热切换语言（P2 6.6）"""
        new_lang = self._cfg["Language"]
        self._lang_mgr = LanguageManager(LANG_DIR, new_lang)

        # 窗口标题
        self.setWindowTitle(self._lang_mgr.t("Main", "Title"))

        # 按钮文本
        self.save_btn.setText(self._lang_mgr.t("Main", "SaveBtn"))
        self.restore_btn.setText(self._lang_mgr.t("Main", "RestoreLatestBtn"))
        self.manage_btn.setText(self._lang_mgr.t("Main", "ManageBtn"))
        self.settings_btn.setText(self._lang_mgr.t("Main", "SettingsBtn"))
        self.quit_btn.setText(self._lang_mgr.t("Main", "QuitBtn"))

        # 托盘菜单
        self.tray_icon.setToolTip(self._lang_mgr.t("Tray", "Tooltip") or "ExplorerSessionSaver")
        menu = self.tray_icon.contextMenu()
        if menu:
            actions = menu.actions()
            if len(actions) >= 6:
                actions[0].setText(self._lang_mgr.t("Tray", "Save"))
                actions[1].setText(self._lang_mgr.t("Tray", "Restore"))
                actions[2].setText(self._lang_mgr.t("Tray", "Manage"))
                actions[3].setText(self._lang_mgr.t("Tray", "Settings"))
                actions[5].setText(self._lang_mgr.t("Tray", "Quit"))

        # 状态栏
        self.statusBar().showMessage(self._lang_mgr.t("Main", "Ready"), 3000)

        logger.info("Language switched to: %s", new_lang)

    def _reload_hotkeys(self):
        """运行时重新注册全局热键（P2 6.6）"""
        self._hk_manager.unregister_all()
        self._hook_hotkeys()
        logger.info("Hotkeys reloaded")

    def _show_startup_notification(self):
        """首次启动时在托盘显示通知（P2 6.9）"""
        self.tray_icon.showMessage(
            self._lang_mgr.t("General", "Info"),
            self._lang_mgr.t("Tray", "Tooltip") or "ExplorerSessionSaver is running",
            QSystemTrayIcon.MessageIcon.Information,
            3000)

    def quit_app(self):
        logger.info("Application quitting")
        self._hk_manager.unregister_all()
        QApplication.instance().quit()

    def closeEvent(self, event):
        """点击关闭按钮 -> 隐藏到托盘"""
        event.ignore()
        self.hide()