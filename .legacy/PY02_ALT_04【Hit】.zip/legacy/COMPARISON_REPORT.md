# v8 与 v10 版本对比分析报告

> **项目**: ExplorerSessionSaver — Windows 资源管理器窗口状态保存/恢复工具  
> **分析日期**: 2026-05-09  
> **分析范围**: `v8/` 与 `v10/` 目录全部源文件

---

## 目录

1. [架构变更（最核心差异）](#1-架构变更最核心差异)
2. [文件变更清单](#2-文件变更清单)
3. [模块级差异详解](#3-模块级差异详解)
4. [新增功能与改进](#4-新增功能与改进)
5. [未变更模块](#5-未变更模块)
6. [总结与评价](#6-总结与评价)

---

## 1. 架构变更（最核心差异）

### v8 架构：QMainWindow + 系统托盘混合模式

```
main()
  ├── QApplication()
  ├── MainWindow(QMainWindow)        ← 有实际主窗口
  │     ├── 系统托盘 QSystemTrayIcon  ← 与窗口共生
  │     ├── 全局热键 HotkeyManager    ← 绑定到 MainWindow
  │     ├── 语言管理 LanguageManager
  │     └── 会话管理 SessionManager
  └── app.exec()
```

- 继承 `QMainWindow`，虽然启动时隐藏（`win.show()` 被注释），但**底层仍然创建了完整的 Qt 窗口**
- 系统托盘作为 MainWindow 的部件，事件循环相互耦合
- 右键菜单同时触发 Qt `activated` 信号和 Windows 原生菜单，**存在"双菜单"Bug**

### v10 架构：纯系统托盘模式（零窗口）

```
main()
  ├── QApplication()
  ├── AppCore(QObject)               ← 无窗口的 QObject
  │     ├── 1×1 QWidget(dummy)       ← 仅提供 HWND 给热键
  │     ├── 系统托盘 QSystemTrayIcon ← 独立存在
  │     ├── 全局热键 HotkeyManager   ← 绑定到 dummy HWND
  │     ├── 语言管理 LanguageManager
  │     ├── 会话管理 SessionManager
  │     └── WinHotkeyFilter          ← 原生事件过滤器
  └── app.exec()
```

- **完全移除 `QMainWindow`**，用纯粹 `QObject` + 1×1 的 `QWidget` dummy 窗口架构
- 系统托盘独立运作，右键菜单仅依赖 `setContextMenu()`，**不连接 `activated` 信号**，根治"双菜单"问题
- 新增原生 Windows 事件过滤器（`WinHotkeyFilter`），延迟安装避免启动竞争

### 架构对比总结

| 维度 | v8 | v10 |
|------|----|-----|
| 基类 | `QMainWindow` | `QObject` |
| 窗口数 | 1 个隐藏主窗口 | 1 个 1×1 dummy 窗口 |
| 托盘菜单 | `activated` + `setContextMenu` 混合 | 仅 `setContextMenu` |
| 原生事件过滤 | 无 | 有（`WinHotkeyFilter`） |
| 启动显示 | 窗口创建（虽隐藏） | 窗口创建（极小，不可见） |
| 右键菜单行为 | 可能双菜单 | 单菜单 |
| 代码耦合度 | 窗口与托盘紧密耦合 | 逻辑与 UI 解耦 |

---

## 2. 文件变更清单

### 新增文件

| 文件 | 说明 |
|------|------|
| `v10/app/app_core.py` (398 行) | 替代 `main_window.py`，纯 QObject 核心逻辑 |
| `v10/config.ini` | 用户配置文件（默认热键为 `Ctrl+Shift+F3` / `Ctrl+Shift+F1`） |

### 删除文件

| 文件 | 说明 |
|------|------|
| `v8/app/main_window.py` (457 行) | v8 主窗口+托盘一体化实现，v10 中完全移除 |

### 核心差异文件

| 文件 | 差异幅度 | 说明 |
|------|----------|------|
| `main.py` | 大幅修改 | v10 精简入口，移除 DPI 策略、移除 MainWindow 导入 |
| `app/app_core.py` | **新增** | v10 新增核心类，替代 main_window.py |
| `app/logger.py` | 小幅 | v10 新增 `log_debug()` 函数 |
| `app/session_manager.py` | 中幅 | v10 新增 `restore_windows_from_session()` 部分恢复功能 |
| `app/manage_dialog.py` | 小幅 | v10 接口扩展，支持部分恢复回调 |
| `app/settings_dialog.py` | 中幅 | v10 新增导入 `logger`，F 键映射改用 Qt.Key 枚举，加入热键临时注销逻辑 |

---

## 3. 模块级差异详解

### 3.1 `main.py` — 程序入口

```python
# v8         25-40 行
def main():
    QApplication.setHighDpiScaleFactorRoundingPolicy(...)  # ← DPI 策略
    app = QApplication(sys.argv)
    app.setApplicationName("ExplorerSessionSaver")         # ← 应用名
    app.setQuitOnLastWindowClosed(False)
    win = MainWindow()                                     # ← 创建主窗口
    sys.exit(app.exec())

# v10        13-28 行
def main():
    logger = get_logger(__name__)
    logger.info("Application starting...")                 # ← 日志标记启动
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    core = AppCore()                                       # ← 纯核心
    sys.exit(app.exec())
```

**差异**:
- v10 移除 DPI 策略（移入 AppCore 或由系统默认处理）
- v10 移除 `setApplicationName`（不影响功能）
- v10 增加启动日志标记
- v10 用 `AppCore()` 替代 `MainWindow()`

### 3.2 `logger.py` — 日志系统

| 函数 | v8 | v10 |
|------|----|-----|
| `log_debug()` | ❌ 不存在 | ✅ 新增（第 46-48 行） |
| `log_info()` | ✅ | ✅ |
| `log_warning()` | ✅ | ✅ |
| `log_error()` | ✅ | ✅ |
| `get_logger()` | ✅ | ✅ |
| `set_language_manager()` | ✅ | ✅ |

**差异**: v10 仅新增 `log_debug()` 函数，余无变化。

### 3.3 `session_manager.py` — 会话管理核心

| 特性 | v8 (539 行) | v10 (541 行) |
|------|-------------|-------------|
| 导入的日志函数 | `get_logger` | `get_logger, log_debug, log_info, log_warning, log_error` |
| `restore_session()` | ✅ | ✅ |
| `restore_windows_from_session()` | ❌ | ✅ **新增**（第 334-400 行） |
| `save_session()` | ✅ | ✅ |
| `get_latest_session_name()` | ✅ | ✅ |
| 错误处理 | 基础 | 增强（更多日志输出） |

**关键新增函数**: `restore_windows_from_session()` 明确支持从会话中恢复部分窗口，接口签名：
```python
def restore_windows_from_session(
    name: str, 
    indices: list[int], 
    progress_callback: Callable | None = None
) -> tuple[int, int]:
```

### 3.4 `manage_dialog.py` — 管理对话框

**v8** 构造函数：
```python
class ManageDialog(QDialog):
    def __init__(self, lang_mgr: LanguageManager):
```

**v10** 构造函数：
```python
class ManageDialog(QDialog):
    def __init__(self, lang_mgr: LanguageManager, 
                 on_restore_session=None, 
                 on_restore_windows=None):
```

**差异**:
- v10 新增 `on_restore_session` / `on_restore_windows` 回调参数
- 恢复操作由外部传入的回调控制（`AppCore` 提供），而不是内部直接调用 `sm.restore_session()`
- 实现了**控制反转**（IoC），解除 ManageDialog 与 session_manager 的直接耦合

### 3.5 `settings_dialog.py` — 设置对话框

| 特性 | v8 (150 行) | v10 (216 行) |
|------|-------------|-------------|
| 导入 logger | ❌ | ✅ `from app.logger import get_logger` |
| F 键映射 | `chr(0x70 + i - 1)` 硬编码 | `Qt.Key.Key_F1` 枚举 + _F_KEY_MAP 字典 |
| KEY_DISPLAY_MAP | 包含 A-Z, 0-9, F1-F12 | 有（用 _F_KEY_MAP 替代） |
| 热键显示映射 | 完整 | 被新的映射方案替代 |
| 设置窗口逻辑 | 基础保存 | 更完整的异常处理 |

**差异**: v10 重写了 F 功能键的映射逻辑，改用 Qt.Key 枚举值和显式字典，更清晰且不易出错。

### 3.6 无差异模块

以下文件两个版本完全一致：

| 文件 | v8 | v10 | 行数 |
|------|----|-----|------|
| `app/common.py` | ✅ | ✅ | 14 行 |
| `app/hotkey_manager.py` | ✅ | ✅ | 120 行 |
| `app/language_manager.py` | ✅ | ✅ | 33 行 |
| `app/config_manager.py` | ✅ | ✅ | ~122 行 |
| `run.bat` | ✅ | ✅ | 18 行 |
| `build.bat` | ✅ | ✅ | 24 行 |
| `requirements.txt` | ✅ | ✅ | 一致 |

---

## 4. 新增功能与改进

### 4.1 部分窗口恢复（v10 核心新增功能）

```
用户打开管理对话框
  └── 选中某个会话组（双击进入）
       ├── [x] 窗口 1: C:\Users\...
       ├── [ ] 窗口 2: D:\Projects\...    ← 仅勾选部分
       └── [ ] 窗口 3: E:\Downloads\...
            └── 点击"恢复选中" → RestorePartialWorker
                → session_manager.restore_windows_from_session()
```

从支持链来看：
- `AppCore._restore_partial()` → `RestorePartialWorker` → `sm.restore_windows_from_session()`
- 用户可以通过管理对话框勾选部分窗口恢复，不再必须恢复整个会话

### 4.2 热键冲突处理改进

v10 `AppCore.open_settings()` 方法中加入：

```python
# 1. 临时注销全局热键 → 避免干扰设置中的热键捕获
self._hk_manager.unregister_all()

# 2. 临时移除原生事件过滤器
QApplication.instance().removeNativeEventFilter(self._hk_filter)

# 3. 设置对话框关闭后重新安装
QApplication.instance().installNativeEventFilter(self._hk_filter)
self._reload_hotkeys()
```

- 设置对话框期间热键不会意外触发
- 设置关闭后自动重新注册

### 4.3 语言热切换增强

v10 `_reload_language()` 在语言切换后**同步刷新托盘菜单文本**（v8 没有此功能）：

```python
menu = self.tray_icon.contextMenu()
if menu:
    actions = menu.actions()
    actions[0].setText(self._lang_mgr.t("Tray", "Save"))
    actions[1].setText(self._lang_mgr.t("Tray", "Restore"))
    # ... 依次更新所有菜单项
```

### 4.4 调试日志

v10 `logger.py` 新增的 `log_debug()` 函数，配合 session_manager.py 中更多的日志输出，有助于开发和排错。

### 4.5 启动通知

v10 在 AppCore 初始化 1.5 秒后弹出托盘提示，告知用户程序已在运行。

---

## 5. 未变更模块

| 模块 | 说明 |
|------|------|
| `app/common.py` | 基础路径函数，完全一致 |
| `app/hotkey_manager.py` | 全局热键注册管理，完全一致 |
| `app/language_manager.py` | 语言 INI 文件加载器，完全一致 |
| `app/config_manager.py` | 配置读写、资源释放，完全一致 |
| `language/` 目录 | 翻译文件，未变更 |
| `tests/` 目录 | 测试文件，未变更 |
| `run.bat` | 启动脚本，完全一致 |
| `build.bat` | 打包脚本，完全一致 |
| `requirements.txt` | 依赖声明，完全一致 |

---

## 6. 总结与评价

### 架构演进评价

v8 → v10 是一次**架构解耦重构**，核心方向为：

```
v8: 窗口优先（QMainWindow 隐藏）
    └── 一切围绕窗口，窗口隐藏但存在

v10: 服务优先（QObject + 托盘）
     └── 没有窗口概念，只有系统服务和热键
```

这一变更解决了 v8 中混合模式的根本问题，使代码逻辑更清晰、行为更可预测。

### 关键改进评分

| 改进项 | 权重 | 说明 |
|--------|------|------|
| 双菜单 Bug 根治 | ★★★ | 仅用 `setContextMenu()`，不连接 `activated` 信号 |
| 部分窗口恢复 | ★★★ | 用户可按需恢复，灵活性大幅提升 |
| 热键安全处理 | ★★☆ | 设置对话框期间防止误触 |
| 语言切换即时刷新 | ★★☆ | 菜单文本立即更新，无需重启 |
| 代码解耦 | ★★★ | IoC 模式，ManageDialog 与 session_manager 解耦 |
| 调试能力 | ★☆☆ | 新增 debug 级别日志 |

### 潜在风险建议

1. **Dummy 窗口的占用**：1×1 窗口虽然不可见，但仍持有 HWND。如果系统资源紧张或特殊场景下，建议确认该 HWND 的生命周期管理是否完善。
2. **事件过滤器延迟安装**：`QTimer.singleShot(0)` 延迟安装原生过滤器，虽然避免了启动竞态，但也引入了时序依赖。
3. **测试覆盖**：`tests/` 目录在两个版本中均未变更，建议为新增的部分恢复功能添加对应测试。

### 总体结论

**v10 是 v8 的架构级升级。** 从"隐藏主窗口"模式演变为"纯系统托盘 + 全局热键"模式，解决了 v8 的核心缺陷（双菜单），同时新增了部分窗口恢复等功能。虽然代码风格有一定的重构痕迹（例如未充分使用类型注解、部分变量命名可优化），但整体架构更优雅、可维护性更强。

---