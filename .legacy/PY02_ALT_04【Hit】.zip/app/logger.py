"""
logger.py
日志系统：输出到 BASE_DIR/logs/explorer-session-saver.log
P2-1: 支持多语言 key-based 日志，通过 LanguageManager 翻译后再写入
"""

import logging
import sys
from typing import Optional

from app.common import get_base_dir

BASE_DIR = get_base_dir()
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "explorer-session-saver.log"

# 日志格式
_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"
_DATE_FMT = "%Y-%m-%d %H:%M:%S"

# 全局 LanguageManager 引用（由 application 启动时设置）
_lang_mgr: Optional["LanguageManager"] = None  # noqa: F821


def set_language_manager(lm: "LanguageManager") -> None:  # noqa: F821
    """设置全局 LanguageManager 供日志翻译使用（P2-1）"""
    global _lang_mgr
    _lang_mgr = lm


def _t(key: str, *args) -> str:
    """通过 LanguageManager 翻译日志 key（如果已设置）"""
    if _lang_mgr is not None:
        try:
            return _lang_mgr.t("Logs", key, *args)
        except Exception:
            pass
    # fallback: 如果 key 没有翻译，直接格式化返回
    msg = key.replace("_", " ").capitalize()
    if args:
        msg = f"{msg}: {' '.join(str(a) for a in args)}"
    return msg


def log_debug(logger: logging.Logger, key: str, *args) -> None:
    """输出多语言 debug 级别日志（P2-1）"""
    logger.debug(_t(key, *args))


def log_info(logger: logging.Logger, key: str, *args) -> None:
    """输出多语言 info 级别日志（P2-1）"""
    logger.info(_t(key, *args))


def log_warning(logger: logging.Logger, key: str, *args) -> None:
    """输出多语言 warning 级别日志（P2-1）"""
    logger.warning(_t(key, *args))


def log_error(logger: logging.Logger, key: str, *args) -> None:
    """输出多语言 error 级别日志（P2-1）"""
    logger.error(_t(key, *args))


def get_logger(name: str) -> logging.Logger:
    """
    获取（或创建）一个按模块命名的 Logger。
    所有 Logger 共享一个文件 Handler，避免重复写入。
    """
    logger = logging.getLogger(name)
    if logger.handlers:  # 已有 Handler，直接返回
        return logger

    logger.setLevel(logging.DEBUG)

    # 文件 Handler（追加模式）
    fh = logging.FileHandler(LOG_FILE, encoding="utf-8", mode="a")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(_FORMAT, _DATE_FMT))
    logger.addHandler(fh)

    # 控制台 Handler（仅在非打包模式输出）
    if not getattr(sys, 'frozen', False):
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(logging.Formatter(_FORMAT, _DATE_FMT))
        logger.addHandler(ch)

    return logger
