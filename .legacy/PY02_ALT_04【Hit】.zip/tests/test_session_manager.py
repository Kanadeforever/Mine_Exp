"""测试 session_manager — 会话 JSON 读写、文件名生成、列表排序"""

import json
from pathlib import Path
from datetime import datetime
import pytest
from app.session_manager import (
    generate_session_name,
    session_exists,
    save_session,
    list_sessions,
    delete_session,
    rename_session,
    get_latest_session_name,
    SessionError,
    _session_path,
)


class TestSessionName:
    def test_generate_format(self):
        name = generate_session_name()
        # 格式: YYYY-MM-DD_HHMMSS (17 chars: e.g. 2026-05-08_143052)
        assert "_" in name
        parts = name.split("_")
        assert len(parts) == 2
        date_part, time_part = parts
        assert len(date_part) == 10  # YYYY-MM-DD
        assert len(time_part) == 6   # HHMMSS


class TestSessionExists:
    def test_exists_true(self, session_dir: Path):
        (session_dir / "test.json").write_text("[]", encoding="utf-8")
        assert session_exists("test") is True

    def test_exists_false(self, session_dir: Path):
        assert session_exists("nonexistent") is False


class TestSaveSession:
    def test_save_without_name_creates_file(self, session_dir: Path):
        count = save_session("test_save")
        assert count >= 0
        assert (session_dir / "test_save.json").exists()

    def test_save_content_is_valid_json(self, session_dir: Path):
        save_session("test_json")
        data = json.loads((session_dir / "test_json.json").read_text("utf-8"))
        assert isinstance(data, list)


class TestListSessions:
    def test_list_empty(self, session_dir: Path):
        assert list_sessions() == []

    def test_list_order(self, session_dir: Path):
        sessions = ["aaa", "bbb", "ccc"]
        for s in sessions:
            (session_dir / f"{s}.json").write_text("[]", encoding="utf-8")
            import time
            time.sleep(0.05)  # 确保 mtime 不同

        listed = list_sessions()
        names = [s["name"] for s in listed]
        # 倒序: ccc, bbb, aaa
        assert names == ["ccc", "bbb", "aaa"]


class TestDeleteSession:
    def test_delete_existing(self, session_dir: Path):
        (session_dir / "delme.json").write_text("[]", encoding="utf-8")
        assert delete_session("delme") is True
        assert not (session_dir / "delme.json").exists()

    def test_delete_nonexistent(self, session_dir: Path):
        assert delete_session("nope") is False


class TestRenameSession:
    def test_rename_success(self, session_dir: Path):
        (session_dir / "old.json").write_text('[{"Path": "C:\\test"}]', encoding="utf-8")
        assert rename_session("old", "new") is True
        assert not (session_dir / "old.json").exists()
        assert (session_dir / "new.json").exists()

    def test_rename_same_name(self, session_dir: Path):
        (session_dir / "same.json").write_text("[]", encoding="utf-8")
        assert rename_session("same", "same") is True

    def test_rename_nonexistent(self, session_dir: Path):
        assert rename_session("nope", "newname") is False

    def test_rename_overwrite_protection(self, session_dir: Path):
        (session_dir / "a.json").write_text("[]", encoding="utf-8")
        (session_dir / "b.json").write_text("[]", encoding="utf-8")
        assert rename_session("a", "b") is False


class TestGetLatestSession:
    def test_latest(self, session_dir: Path):
        (session_dir / "first.json").write_text("[]", encoding="utf-8")
        import time
        time.sleep(0.05)
        (session_dir / "second.json").write_text("[]", encoding="utf-8")
        time.sleep(0.05)
        (session_dir / "third.json").write_text("[]", encoding="utf-8")

        assert get_latest_session_name() == "third"

    def test_no_sessions(self, session_dir: Path):
        assert get_latest_session_name() is None