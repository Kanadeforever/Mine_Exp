"""
main_window.py
主窗口 + 系统托盘。实现所有用户交互逻辑。
"""

import sys
from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QSystemTrayIcon, QMenu,
    QMessageBox, QWidget, QVBoxLayout, QPushButton, QLabel,
    QHBoxLayout, QLineEdit, QListWidget, QInputDialog, QStyle,
    QProgressDialog,
)
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt6.QtGui import QIcon, QAction

from app.language_manager import LanguageManager
from app import session_manager as sm
from app.settings_dialog import SettingsDialog
from app.manage_dialog import ManageDialog
from app.config_manager import load_config, save_config, BASE_DIR, LANGUAGE_DIR
from app.logger import get_logger

logger = get_logger(__name__)

LANG_DIR = LANGUAGE_DIR
from app.hotkey_manager import (HotkeyManager, WinHotkeyFilter)


class RestoreWorker(QThread):
    """异步恢复工作线程"""
    progress = pyqtSignal(int, int, str)  # success, failed, current_path
    finished = pyqtSignal(int, int)       # success, failed
    error = pyqtSignal(str)

    def __init__(self, session_name: str):
        super().__init__()
        self._name = session_name

    def run(self):
        try:
            succ, fail = sm.restore_session(
                self._name,
                progress_callback=lambda s, f, p: self.progress.emit(s, f, p)
            )
            self.finished.emit(succ, fail)
        except sm.SessionError as e:
            self.error.emit(str(e))
        except Exception as e:
            logger.exception("Restore worker error: %s", e)
            self.error.emit(str(e))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # ── 配置和语言 ──
        self._cfg = load_config()
        self._lang_mgr = LanguageManager(LANG_DIR, self._cfg["Language"])
        self.setWindowTitle(self._lang_mgr.t("Main", "Title"))

        # ── UI ──
        self.setMinimumSize(400, 300)
        self.center_widget = QWidget()
        self.setCentralWidget(self.center_widget)
        self.setup_ui()

        # ── 系统托盘 ──
        self.setup_tray()

        # ── 全局热键 ──
        self._hk_manager = HotkeyManager(int(self.winId()))
        self._hk_filter = WinHotkeyFilter(self._hk_manager)
        self._hook_hotkeys()

        # ── 安装原生事件过滤器 ──
        self._native_filter_installed = False
        QTimer.singleShot(0, self._install_native_filter)

        # ── 状态栏 ──
        self.statusBar().showMessage(self._lang_mgr.t("Main", "Ready"))

    # ── UI 布局 ───────────────────────────────────────
    def setup_ui(self):
        ly = QVBoxLayout(self.center_widget)
        ly.setContentsMargins(12, 12, 12, 12)
        ly.setSpacing(8)

        label = QLabel(self._lang_mgr.t("Main", "Hint"))
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ly.addWidget(label)

        self.save_btn = QPushButton(self._lang_mgr.t("Main", "SaveBtn"))
        self.save_btn.clicked.connect(self.save_session)
        ly.addWidget(self.save_btn)

        self.restore_btn = QPushButton(self._lang_mgr.t("Main", "RestoreLatestBtn"))
        self.restore_btn.clicked.connect(self.do_quick_restore)
        ly.addWidget(self.restore_btn)

        self.manage_btn = QPushButton(self._lang_mgr.t("Main", "ManageBtn"))
        self.manage_btn.clicked.connect(self.manage_sessions)
        ly.addWidget(self.manage_btn)

        self.settings_btn = QPushButton(self._lang_mgr.t("Main", "SettingsBtn"))
        self.settings_btn.clicked.connect(self.open_settings)
        ly.addWidget(self.settings_btn)

        self.quit_btn = QPushButton(self._lang_mgr.t("Main", "QuitBtn"))
        self.quit_btn.clicked.connect(self.quit_app)
        ly.addWidget(self.quit_btn)

        ly.addStretch()

    # ── 系统托盘 ───────────────────────────────────────
    def setup_tray(self):
        self.tray_icon = QSystemTrayIcon(self)
        icon_path = BASE_DIR / "app" / "resources" / "icon.png"
        if icon_path.exists():
            self.tray_icon.setIcon(QIcon(str(icon_path)))
        else:
            # fallback 到 Qt 内置图标
            self.tray_icon.setIcon(
                self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)
            )
        self.tray_icon.setToolTip(self._lang_mgr.t("Tray", "Tooltip") or "ExplorerSessionSaver")

        menu = QMenu()
        save_a = menu.addAction(self._lang_mgr.t("Tray", "Save"))
        save_a.triggered.connect(self.save_session)
        restore_a = menu.addAction(self._lang_mgr.t("Tray", "Restore"))
        restore_a.triggered.connect(self.restore_session)
        manage_a = menu.addAction(self._lang_mgr.t("Tray", "Manage"))
        manage_a.triggered.connect(self.manage_sessions)
        settings_a = menu.addAction(self._lang_mgr.t("Tray", "Settings"))
        settings_a.triggered.connect(self.open_settings)
        menu.addSeparator()
        quit_a = menu.addAction(self._lang_mgr.t("Tray", "Quit"))
        quit_a.triggered.connect(self.quit_app)
        self.tray_icon.setContextMenu(menu)

        self.tray_icon.activated.connect(self._tray_activated)
        self.tray_icon.show()

    def _tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.show()
            self.raise_()
            self.activateWindow()

    # ── 全局热键 ───────────────────────────────────────
    def _hook_hotkeys(self):
        """注册热键并处理注册错误（P0 6.2）"""
        hotkeys = [
            ("SaveSession", self._cfg["SaveSession"], self.save_session),
            ("QuickRestore", self._cfg["QuickRestore"], self.do_quick_restore),
        ]
        errors = []
        for name, combo, callback in hotkeys:
            try:
                self._hk_manager.register(combo, callback)
                logger.info("Hotkey registered: %s = %s", name, combo)
            except Exception as e:
                errors.append(f"{name} ({combo}): {e}")
                logger.warning("Failed to register hotkey %s: %s", combo, e)

        if errors:
            msg = "; ".join(errors)
            self.statusBar().showMessage(
                self._lang_mgr.t("Main", "HotkeyError") % msg, 8000)

    def _install_native_filter(self):
        if not self._native_filter_installed:
            try:
                QApplication.instance().installNativeEventFilter(self._hk_filter)
                self._native_filter_installed = True
                logger.info("Native event filter installed")
            except Exception as e:
                msg = self._lang_mgr.t("Main", "HotkeyFilterFailed")
                self.statusBar().showMessage(msg)
                logger.warning("Failed to install native event filter: %s", e)

    def __del__(self):
        self._hk_manager.unregister_all()

    # ── 操作 ───────────────────────────────────────────
    def save_session(self):
        try:
            name = sm.generate_session_name()
            count = sm.save_session(name)
            msg = self._lang_mgr.t("Main", "Saved", name, str(count))
            self.statusBar().showMessage(msg, 5000)
            self.tray_icon.showMessage(
                self._lang_mgr.t("General", "Success"),
                msg,
                QSystemTrayIcon.MessageIcon.Information,
                3000)
            logger.info("Session saved: %s (%d windows)", name, count)
        except sm.SessionError as e:
            logger.error("Save session failed: %s", e)
            self.statusBar().showMessage(str(e), 5000)
        except Exception as e:
            logger.exception("Unexpected error saving session: %s", e)
            self.statusBar().showMessage(str(e), 5000)

    def do_quick_restore(self):
        """快速恢复（最新会话）"""
        name = sm.get_latest_session_name()
        if name is None:
            msg = self._lang_mgr.t("Main", "NoSessions")
            self.statusBar().showMessage(msg, 3000)
            self.tray_icon.showMessage(
                self._lang_mgr.t("General", "Info"),
                msg,
                QSystemTrayIcon.MessageIcon.Information,
                3000)
            return
        logger.info("Quick restore: %s", name)
        self._restore(name)

    def restore_session(self):
        """（保留供外部调用）恢复最新会话"""
        self.do_quick_restore()

    def restore_session_by_name(self, name: str):
        """按名称恢复会话（供 ManageDialog 调用）"""
        self._restore(name)
        # 让主窗口可见
        self.show()
        self.raise_()
        self.activateWindow()

    def _restore(self, name: str):
        """
        使用 QThread 异步恢复 + 进度对话框（P1 6.3）。
        """
        # 禁用按钮防止重复操作
        self.save_btn.setEnabled(False)
        self.restore_btn.setEnabled(False)
        self.manage_btn.setEnabled(False)

        progress = QProgressDialog(
            self._lang_mgr.t("Main", "RestoringProgress", name),
            self._lang_mgr.t("General", "Cancel"),
            0, 100, self)
        progress.setWindowTitle(self._lang_mgr.t("Main", "Restoring"))
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        progress.show()

        # 启动工作线程
        self._worker = RestoreWorker(name)
        self._worker.progress.connect(
            lambda s, f, p: self._on_restore_progress(progress, s, f, p))
        self._worker.finished.connect(
            lambda s, f: self._on_restore_done(progress, name, s, f))
        self._worker.error.connect(
            lambda e: self._on_restore_error(progress, name, e))
        self._worker.finished.connect(self._worker.deleteLater)
        self._worker.error.connect(self._worker.deleteLater)
        progress.canceled.connect(self._on_restore_cancel)
        self._worker.start()

    def _on_restore_progress(self, progress: QProgressDialog, success: int, failed: int, status: str):
        progress.setLabelText(status)
        progress.setValue(success + failed)

    def _on_restore_cancel(self):
        if hasattr(self, '_worker') and self._worker.isRunning():
            self._worker.terminate()
            self._worker.wait()
            logger.info("Restore cancelled by user")
            self._reenable_buttons()

    def _on_restore_done(self, progress: QProgressDialog, name: str, success: int, failed: int):
        progress.close()
        msg = self._lang_mgr.t("Main", "Restored", str(success), str(failed))
        self.statusBar().showMessage(msg, 5000)
        self.tray_icon.showMessage(
            self._lang_mgr.t("General", "Success"),
            msg,
            QSystemTrayIcon.MessageIcon.Information,
            3000)
        logger.info("Restored %s: %d success, %d failed", name, success, failed)
        self._reenable_buttons()

    def _on_restore_error(self, progress: QProgressDialog, name: str, error_msg: str):
        progress.close()
        logger.error("Restore failed for %s: %s", name, error_msg)
        QMessageBox.warning(self, self._lang_mgr.t("General", "Error"), error_msg)
        self._reenable_buttons()

    def _reenable_buttons(self):
        self.save_btn.setEnabled(True)
        self.restore_btn.setEnabled(True)
        self.manage_btn.setEnabled(True)

    def manage_sessions(self):
        dlg = ManageDialog(self._lang_mgr, self)
        dlg.exec()
        # 恢复后刷新状态
        latest = sm.get_latest_session_name()
        if latest:
            self.statusBar().showMessage(
                self._lang_mgr.t("Main", "Ready"), 3000)

    def open_settings(self):
        dlg = SettingsDialog(self._cfg, self._lang_mgr, LANG_DIR, self)
        if dlg.exec() == SettingsDialog.DialogCode.Accepted:
            new_cfg = dlg.get_config()
            if new_cfg != self._cfg:
                self._cfg = new_cfg
                save_config(self._cfg)
                QMessageBox.information(
                    self, self._lang_mgr.t("General", "Info"),
                    self._lang_mgr.t("Settings", "RestartHint"))

    def quit_app(self):
        logger.info("Application quitting")
        self._hk_manager.unregister_all()
        QApplication.instance().quit()

    def closeEvent(self, event):
        """点击关闭按钮 -> 隐藏到托盘"""
        event.ignore()
        self.hide()