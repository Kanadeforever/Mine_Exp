#!/usr/bin/env python3
"""
ExplorerSessionSaver
保存与恢复 Windows 资源管理器（Explorer）窗口状态的桌面工具。
原始 AHK 脚本的 PyQt6 重构版。
"""

import sys
from pathlib import Path

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt

from app.main_window import MainWindow


def get_base_dir() -> Path:
    """获取程序所在目录（兼容脚本和 PyInstaller 打包）"""
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent


def main():
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)

    app = QApplication(sys.argv)
    app.setApplicationName("ExplorerSessionSaver")
    app.setQuitOnLastWindowClosed(False)  # 允许隐藏到托盘

    win = MainWindow()
    # 启动时隐藏到托盘
    # win.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()