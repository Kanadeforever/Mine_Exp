"""
settings_dialog.py
设置对话框（语言、热键配置）
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
    QTabWidget, QWidget, QLabel, QComboBox, QPushButton,
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QKeyEvent
from PyQt6.QtWidgets import QLineEdit

from app.language_manager import LanguageManager
from app.hotkey_manager import MOD_NAME_MAP, VK_MAP

# ─── 热键捕获输入框 ──────────────────────────────────

KEY_DISPLAY_MAP = {
    **{chr(0x41 + i): chr(0x41 + i) for i in range(26)},
    **{chr(0x30 + i): chr(0x30 + i) for i in range(10)},
    "F1": "F1", "F2": "F2", "F3": "F3", "F4": "F4", "F5": "F5",
    "F6": "F6", "F7": "F7", "F8": "F8", "F9": "F9", "F10": "F10",
    "F11": "F11", "F12": "F12",
}

MOD_QT_MAP = {
    Qt.KeyboardModifier.ControlModifier: "Ctrl",
    Qt.KeyboardModifier.ShiftModifier: "Shift",
    Qt.KeyboardModifier.AltModifier: "Alt",
    Qt.KeyboardModifier.MetaModifier: "Win",
}


class HotkeyLineEdit(QLineEdit):
    """点击后捕获按键组合，显示为人读字符串如 Ctrl+Shift+S"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setPlaceholderText("点击并按下快捷键...")
        self._capturing = False

    def focusInEvent(self, event):
        self._capturing = True
        self.setText("...")
        super().focusInEvent(event)

    def focusOutEvent(self, event):
        self._capturing = False
        super().focusOutEvent(event)

    def keyPressEvent(self, event):
        if not self._capturing:
            return super().keyPressEvent(event)

        mods = event.modifiers()
        key = event.key()

        if key in (Qt.Key.Key_Control, Qt.Key.Key_Shift, Qt.Key.Key_Alt, Qt.Key.Key_Meta):
            return  # 纯修饰键不处理

        parts = []
        for qmod, name in MOD_QT_MAP.items():
            if mods & qmod:
                parts.append(name)

        # 映射按键名
        display = KEY_DISPLAY_MAP.get(chr(key).upper() if 0x20 <= key <= 0xFF else key)
        if display is None:
            if 0x20 <= key <= 0xFF:
                display = chr(key)
            elif hasattr(Qt.Key, f"Key_F{key - 0x70 + 1}"):
                display = f"F{key - 0x70 + 1}"
            else:
                return

        parts.append(display)
        self.setText("+".join(parts))


# ─── 设置对话框 ──────────────────────────────────────

class SettingsDialog(QDialog):
    def __init__(self, current_cfg: dict, lang_mgr: LanguageManager, lang_dir, parent=None):
        super().__init__(parent)
        self._cfg = dict(current_cfg)
        self._lm = lang_mgr
        self._lang_dir = lang_dir
        self.setWindowTitle(self._lm.t("Settings", "Title"))
        self.setMinimumWidth(420)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        layout.addWidget(tabs)

        # ── General 标签 ──
        gen = QWidget()
        gl = QVBoxLayout(gen)
        fl = QFormLayout()
        gl.addLayout(fl)

        lang_files = [f.stem for f in self._lang_dir.glob("*.ini")]
        if "zh_CN" not in lang_files:
            lang_files.insert(0, "zh_CN")
        self.lang_combo = QComboBox()
        self.lang_combo.addItems(lang_files)
        idx = lang_files.index(self._cfg["Language"]) if self._cfg["Language"] in lang_files else 0
        self.lang_combo.setCurrentIndex(idx)
        fl.addRow(self._lm.t("Settings", "LangLabel") + ":", self.lang_combo)
        gl.addStretch()
        tabs.addTab(gen, self._lm.t("Settings", "TabGeneral"))

        # ── Hotkeys 标签 ──
        hk = QWidget()
        hl = QVBoxLayout(hk)
        hf = QFormLayout()
        hl.addLayout(hf)

        self.hk_save = HotkeyLineEdit()
        self.hk_save.setText(self._cfg["SaveSession"])
        hf.addRow(self._lm.t("Settings", "HKSaveLabel") + ":", self.hk_save)

        self.hk_quick = HotkeyLineEdit()
        self.hk_quick.setText(self._cfg["QuickRestore"])
        hf.addRow(self._lm.t("Settings", "HKQuickRestore") + ":", self.hk_quick)

        hl.addWidget(QLabel(self._lm.t("Settings", "RestartHint")))
        hl.addStretch()
        tabs.addTab(hk, self._lm.t("Settings", "TabHotkeys"))

        # ── 按钮行 ──
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        save_btn = QPushButton(self._lm.t("Settings", "SaveBtn"))
        save_btn.clicked.connect(self.accept)
        btn_row.addWidget(save_btn)
        close_btn = QPushButton(self._lm.t("ManageSessions", "CloseBtn"))
        close_btn.clicked.connect(self.reject)
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

    def get_config(self) -> dict:
        return {
            "Language": self.lang_combo.currentText(),
            "SaveSession": self.hk_save.text(),
            "QuickRestore": self.hk_quick.text(),
        }