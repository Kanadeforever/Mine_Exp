"""
session_manager.py
替换所有 PowerShell 脚本，通过 win32com 直接操作 Shell.Application COM 接口。

替代脚本：
  - Save-Session.ps1
  - Restore-Session.ps1
  - List-Sessions.ps1
  - Delete-Session.ps1
  - Get-ExplorerSessions.ps1
"""

import json
import ctypes
import ctypes.wintypes
import time
import threading
from pathlib import Path
from datetime import datetime

import pythoncom
import win32com.client

from app.config_manager import SESSION_DIR

# ─── Win32 ─────────────────────────────────────────────
_USER32 = ctypes.windll.user32


class SessionError(Exception):
    """会话操作异常基类"""
    pass


# ─── 工具函数 ──────────────────────────────────────────

def _init_com():
    """在当前线程初始化 COM（每个线程只需调用一次）"""
    try:
        pythoncom.CoInitialize()
    except Exception:
        pass


def _get_shell():
    """获取 Shell.Application COM 对象"""
    _init_com()
    return win32com.client.Dispatch("Shell.Application")


def _session_path(name: str) -> Path:
    return SESSION_DIR / f"{name}.json"


def _decode_variant(v):
    """将 COM VARIANT 转为 Python 原生类型"""
    if v is None:
        return None
    try:
        return v  # pywin32 自动转换大部分类型
    except Exception:
        return str(v)


# ─── 会话文件名（带时间戳） ──────────────────────────

def generate_session_name() -> str:
    """生成默认会话名称：2026-05-08_143052"""
    return datetime.now().strftime("%Y-%m-%d_%H%M%S")


# ─── 核心 API ──────────────────────────────────────────

def get_open_windows() -> list[dict]:
    """
    获取所有打开的 Explorer 窗口信息。
    对应 Get-ExplorerSessions.ps1
    返回: [{"Path": str, "Left": int, "Top": int, "Width": int, "Height": int}, ...]
    """
    results = []
    shell = _get_shell()
    for w in shell.Windows():
        try:
            folder = w.Document
            if folder is None:
                continue
            self_path = folder.Folder.Self.Path
            if self_path is None:
                continue
            results.append({
                "Path": str(self_path),
                "Left": int(getattr(w, "Left", 0)),
                "Top": int(getattr(w, "Top", 0)),
                "Width": int(getattr(w, "Width", 0)),
                "Height": int(getattr(w, "Height", 0)),
            })
        except Exception:
            # 非资源管理器窗口（IE、控制面板等）跳过
            continue
    return results


def save_session(name: str = None) -> int:
    """
    保存当前 Explorer 窗口状态。
    对应 Save-Session.ps1
    返回: 保存的窗口数量
    """
    if name is None:
        name = generate_session_name()
    data = get_open_windows()
    path = _session_path(name)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return len(data)


def list_sessions() -> list[dict]:
    """
    列出已保存的会话。
    对应 List-Sessions.ps1
    返回: [{"name": str, "count": int, "time": datetime}, ...]
         按时间倒序排列
    """
    sessions = []
    for f in sorted(SESSION_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            data = json.loads(f.read_text("utf-8"))
            count = len(data) if isinstance(data, list) else 0
        except Exception:
            count = 0
        mtime = datetime.fromtimestamp(f.stat().st_mtime)
        sessions.append({
            "name": f.stem,
            "count": count,
            "time": mtime,
            "time_str": mtime.strftime("%Y-%m-%d %H:%M:%S"),
        })
    return sessions


def delete_session(name: str) -> bool:
    """
    删除指定会话。
    对应 Delete-Session.ps1
    返回: True 删除成功, False 未找到
    """
    path = _session_path(name)
    if path.exists():
        path.unlink()
        return True
    return False


def restore_session(name: str) -> tuple[int, int]:
    """
    恢复指定会话。
    对应 Restore-Session.ps1
    返回: (成功数, 失败数)
    """
    path = _session_path(name)
    if not path.exists():
        raise SessionError(f"Session not found: {name}")

    data = json.loads(path.read_text("utf-8"))
    if not isinstance(data, list):
        raise SessionError(f"Invalid session data: {name}")

    shell = _get_shell()
    success = 0
    failed = 0

    for item in data:
        try:
            path_str = str(item.get("Path", ""))
            if not path_str:
                failed += 1
                continue

            window = shell.Open(path_str)
            if window is None:
                failed += 1
                continue

            # 等待窗口创建完成
            import time
            time.sleep(0.3)

            # 获取 HWND 并设置位置
            hwnd = int(window.HWND)
            if hwnd == 0:
                failed += 1
                continue

            left = int(item.get("Left", 0))
            top = int(item.get("Top", 0))
            width = int(item.get("Width", 800))
            height = int(item.get("Height", 600))

            _USER32.SetWindowPos(
                ctypes.wintypes.HWND(hwnd),
                ctypes.wintypes.HWND(0),  # HWND_TOP
                ctypes.c_int(left),
                ctypes.c_int(top),
                ctypes.c_int(width),
                ctypes.c_int(height),
                ctypes.c_uint(0x0040),  # SWP_SHOWWINDOW
            )
            success += 1
        except Exception:
            failed += 1

    return success, failed


def session_exists(name: str) -> bool:
    """检查会话是否存在"""
    return _session_path(name).exists()