"""
manage_dialog.py
会话管理对话框（列表、删除）
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QListWidget, QPushButton, QMessageBox,
)
from PyQt6.QtCore import Qt

from app.language_manager import LanguageManager
from app import session_manager as sm


class ManageDialog(QDialog):
    def __init__(self, lang_mgr: LanguageManager, parent=None):
        super().__init__(parent)
        self._lm = lang_mgr
        self._sessions = []
        self.setWindowTitle(self._lm.t("ManageSessions", "Title"))
        self.setMinimumSize(480, 300)
        self.setup_ui()
        self.refresh()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(self._lm.t("ManageSessions", "SelectHint")))

        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget)

        btn_row = QHBoxLayout()
        delete_btn = QPushButton(self._lm.t("ManageSessions", "DeleteBtn"))
        delete_btn.clicked.connect(self.delete_selected)
        btn_row.addWidget(delete_btn)

        refresh_btn = QPushButton(self._lm.t("ManageSessions", "RefreshBtn"))
        refresh_btn.clicked.connect(self.refresh)
        btn_row.addWidget(refresh_btn)

        btn_row.addStretch()
        close_btn = QPushButton(self._lm.t("ManageSessions", "CloseBtn"))
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(close_btn)
        layout.addLayout(btn_row)

    def refresh(self):
        self.list_widget.clear()
        self._sessions = sm.list_sessions()
        for s in self._sessions:
            self.list_widget.addItem(f"{s['name']} | {s['count']} windows | {s['time_str']}")

    def delete_selected(self):
        item = self.list_widget.currentItem()
        if not item:
            QMessageBox.information(
                self, self._lm.t("ManageSessions", "DeleteTitle"),
                self._lm.t("ManageSessions", "SelectFirst"))
            return

        name = item.text().split(" | ")[0]
        ret = QMessageBox.question(
            self, self._lm.t("ManageSessions", "ConfirmTitle"),
            self._lm.t("ManageSessions", "Confirm", name),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if ret != QMessageBox.StandardButton.Yes:
            return

        ok = sm.delete_session(name)
        if ok:
            self.refresh()
        else:
            QMessageBox.warning(
                self, self._lm.t("General", "Error"),
                self._lm.t("ManageSessions", "DeleteFail"))