"""
config_manager.py
配置读写，替代 main.py 中的 load_config/save_config 函数。
"""

import sys
import shutil
from pathlib import Path
import configparser


def get_base_dir() -> Path:
    """获取程序所在目录（兼容脚本和 PyInstaller 打包）"""
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR = get_base_dir()
CONFIG_FILE = BASE_DIR / "config.ini"
SESSION_DIR = BASE_DIR / "Session"
SESSION_DIR.mkdir(parents=True, exist_ok=True)
LANGUAGE_DIR = BASE_DIR / "language"


def init_resources():
    """
    PyInstaller frozen 模式：首次启动时释放 language/ 和资源到程序目录，
    使用户可以在 exe 旁边自由编辑/添加翻译文件。
    """
    if not getattr(sys, 'frozen', False):
        return  # 脚本模式直接读取项目下的文件
    # ── 语言文件 ──
    src_lang = Path(sys._MEIPASS) / "language"
    if src_lang.exists() and not LANGUAGE_DIR.exists():
        LANGUAGE_DIR.mkdir(parents=True, exist_ok=True)
        for f in src_lang.iterdir():
            if f.is_file() and f.suffix.lower() == ".ini":
                shutil.copy2(f, LANGUAGE_DIR / f.name)
    # ── 资源文件（图标等） ──
    src_res = Path(sys._MEIPASS) / "app" / "resources"
    if src_res.exists():
        dst_res = BASE_DIR / "app" / "resources"
        if not dst_res.exists():
            dst_res.mkdir(parents=True, exist_ok=True)
            for f in src_res.iterdir():
                if f.is_file():
                    shutil.copy2(f, dst_res / f.name)


# 模块加载时自动释放资源
init_resources()

DEFAULT_CONFIG = {
    "Language": "zh_CN",
    "SaveSession": "Ctrl+Shift+S",
    "QuickRestore": "Ctrl+Shift+R",
}


class _IniParser(configparser.ConfigParser):
    """保留 Key 原始大小写的 ConfigParser"""
    def optionxform(self, optionstr: str) -> str:
        return optionstr  # 不转小写


def read_ini(path: Path) -> dict:
    """读取 UTF-8 INI 文件，返回 {section: {key: value}}"""
    result = {}
    if not path.exists():
        return result
    cp = _IniParser(interpolation=None)
    cp.read(str(path), encoding="utf-8-sig")  # str(Path) 兼容 configparser, utf-8-sig 兼容 BOM
    for sec in cp.sections():
        result[sec] = {k: v for k, v in cp.items(sec)}
    return result


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if not CONFIG_FILE.exists():
        return cfg
    try:
        raw = read_ini(CONFIG_FILE)
        if "General" in raw:
            cfg["Language"] = raw["General"].get("Language", "zh_CN")
        if "Hotkeys" in raw:
            cfg["SaveSession"] = raw["Hotkeys"].get("SaveSession", "Ctrl+Shift+S")
            cfg["QuickRestore"] = raw["Hotkeys"].get("QuickRestore", "Ctrl+Shift+R")
    except Exception:
        pass
    return cfg


def save_config(cfg: dict):
    lines = [
        "[General]",
        f"Language={cfg['Language']}",
        "",
        "[Hotkeys]",
        f"SaveSession={cfg['SaveSession']}",
        f"QuickRestore={cfg['QuickRestore']}",
        "",
    ]
    CONFIG_FILE.write_text("\n".join(lines), encoding="utf-8")