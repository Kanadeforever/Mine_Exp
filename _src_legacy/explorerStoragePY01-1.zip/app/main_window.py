"""
main_window.py
主窗口 + 系统托盘。实现所有用户交互逻辑。
"""

import sys
from pathlib import Path

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QSystemTrayIcon, QMenu,
    QMessageBox, QWidget, QVBoxLayout, QPushButton, QLabel,
    QHBoxLayout, QLineEdit, QListWidget, QInputDialog, QStyle,
)
from PyQt6.QtCore import Qt, QTimer, QAbstractNativeEventFilter
from PyQt6.QtGui import QIcon, QAction

from app.language_manager import LanguageManager
from app import session_manager as sm
from app.settings_dialog import SettingsDialog
from app.manage_dialog import ManageDialog
from app.config_manager import load_config, save_config, BASE_DIR, LANGUAGE_DIR
LANG_DIR = LANGUAGE_DIR
from app.hotkey_manager import (HotkeyManager, WinHotkeyFilter)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # ── 配置和语言 ──
        self._cfg = load_config()
        self._lang_mgr = LanguageManager(LANG_DIR, self._cfg["Language"])
        self.setWindowTitle(self._lang_mgr.t("Main", "Title"))

        # ── UI ──
        self.setMinimumSize(400, 300)
        self.center_widget = QWidget()
        self.setCentralWidget(self.center_widget)
        self.setup_ui()

        # ── 系统托盘 ──
        self.setup_tray()

        # ── 全局热键 ──
        self._hk_manager = HotkeyManager(int(self.winId()))
        self._hk_filter = WinHotkeyFilter(self._hk_manager)
        self._hook_hotkeys()

        # ── 安装原生事件过滤器 ──
        self._native_filter_installed = False
        QTimer.singleShot(0, self._install_native_filter)

        # ── 状态栏 ──
        self.statusBar().showMessage(self._lang_mgr.t("Main", "Ready"))

    # ── UI 布局 ───────────────────────────────────────
    def setup_ui(self):
        ly = QVBoxLayout(self.center_widget)
        ly.setContentsMargins(12, 12, 12, 12)
        ly.setSpacing(8)

        label = QLabel(self._lang_mgr.t("Main", "Hint"))
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ly.addWidget(label)

        self.save_btn = QPushButton(self._lang_mgr.t("Main", "SaveBtn"))
        self.save_btn.clicked.connect(self.save_session)
        ly.addWidget(self.save_btn)

        self.restore_btn = QPushButton(self._lang_mgr.t("Main", "RestoreBtn"))
        self.restore_btn.clicked.connect(self.restore_session)
        ly.addWidget(self.restore_btn)

        self.manage_btn = QPushButton(self._lang_mgr.t("Main", "ManageBtn"))
        self.manage_btn.clicked.connect(self.manage_sessions)
        ly.addWidget(self.manage_btn)

        self.settings_btn = QPushButton(self._lang_mgr.t("Main", "SettingsBtn"))
        self.settings_btn.clicked.connect(self.open_settings)
        ly.addWidget(self.settings_btn)

        self.quit_btn = QPushButton(self._lang_mgr.t("Main", "QuitBtn"))
        self.quit_btn.clicked.connect(self.quit_app)
        ly.addWidget(self.quit_btn)

        ly.addStretch()

    # ── 系统托盘 ───────────────────────────────────────
    def setup_tray(self):
        self.tray_icon = QSystemTrayIcon(self)
        icon_path = BASE_DIR / "app" / "resources" / "icon.png"
        if icon_path.exists():
            self.tray_icon.setIcon(QIcon(str(icon_path)))
        else:
            # fallback 到 Qt 内置图标
            self.tray_icon.setIcon(
                self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon)
            )
        self.tray_icon.setToolTip(self._lang_mgr.t("Tray", "Tooltip") or "ExplorerSessionSaver")

        menu = QMenu()
        save_a = menu.addAction(self._lang_mgr.t("Tray", "Save"))
        save_a.triggered.connect(self.save_session)
        restore_a = menu.addAction(self._lang_mgr.t("Tray", "Restore"))
        restore_a.triggered.connect(self.restore_session)
        manage_a = menu.addAction(self._lang_mgr.t("Tray", "Manage"))
        manage_a.triggered.connect(self.manage_sessions)
        settings_a = menu.addAction(self._lang_mgr.t("Tray", "Settings"))
        settings_a.triggered.connect(self.open_settings)
        menu.addSeparator()
        quit_a = menu.addAction(self._lang_mgr.t("Tray", "Quit"))
        quit_a.triggered.connect(self.quit_app)
        self.tray_icon.setContextMenu(menu)

        self.tray_icon.activated.connect(self._tray_activated)
        self.tray_icon.show()

    def _tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.show()
            self.raise_()
            self.activateWindow()

    # ── 全局热键 ───────────────────────────────────────
    def _hook_hotkeys(self):
        self._hk_manager.register(self._cfg["SaveSession"], self.save_session)
        self._hk_manager.register(self._cfg["QuickRestore"], self.do_quick_restore)

    def _install_native_filter(self):
        if not self._native_filter_installed:
            try:
                QApplication.instance().installNativeEventFilter(self._hk_filter)
                self._native_filter_installed = True
            except Exception:
                self.statusBar().showMessage("Hotkey filter failed (run as admin?)")

    def __del__(self):
        self._hk_manager.unregister_all()

    # ── 操作 ───────────────────────────────────────────
    def save_session(self):
        try:
            name = sm.generate_session_name()
            count = sm.save_session(name)
            msg = self._lang_mgr.t("Main", "Saved", name, str(count))
            self.statusBar().showMessage(msg, 5000)
            self.tray_icon.showMessage(
                self._lang_mgr.t("General", "Success"),
                msg,
                QSystemTrayIcon.MessageIcon.Information,
                3000)
        except Exception as e:
            self.statusBar().showMessage(str(e), 5000)

    def do_quick_restore(self):
        """快速恢复（最新会话）"""
        sessions = sm.list_sessions()
        if not sessions:
            self.tray_icon.showMessage(
                self._lang_mgr.t("General", "Info"),
                self._lang_mgr.t("Main", "NoSessions"),
                QSystemTrayIcon.MessageIcon.Information,
                3000)
            return
        latest = sessions[0]["name"]
        self._restore(latest)

    def restore_session(self):
        sessions = sm.list_sessions()
        if not sessions:
            QMessageBox.information(
                self, self._lang_mgr.t("General", "Info"),
                self._lang_mgr.t("Main", "NoSessions"))
            return

        names = [s["name"] for s in sessions]
        items = [f"{s['name']} | {s['count']} windows | {s['time_str']}" for s in sessions]
        name, ok = QInputDialog.getItem(
            self, self._lang_mgr.t("Main", "RestoreTitle"),
            self._lang_mgr.t("Main", "RestoreHint"), items, 0, False)
        if not ok:
            return
        selected_name = name.split(" | ")[0]
        self._restore(selected_name)

    def _restore(self, name):
        try:
            succ, fail = sm.restore_session(name)
            msg = self._lang_mgr.t("Main", "Restored", str(succ), str(fail))
            self.statusBar().showMessage(msg, 5000)
            self.tray_icon.showMessage(
                self._lang_mgr.t("General", "Success"),
                msg,
                QSystemTrayIcon.MessageIcon.Information,
                3000)
        except Exception as e:
            QMessageBox.warning(self, self._lang_mgr.t("General", "Error"), str(e))

    def manage_sessions(self):
        dlg = ManageDialog(self._lang_mgr, self)
        dlg.exec()

    def open_settings(self):
        dlg = SettingsDialog(self._cfg, self._lang_mgr, LANG_DIR, self)
        if dlg.exec() == SettingsDialog.DialogCode.Accepted:
            new_cfg = dlg.get_config()
            if new_cfg != self._cfg:
                self._cfg = new_cfg
                save_config(self._cfg)
                QMessageBox.information(
                    self, self._lang_mgr.t("General", "Info"),
                    self._lang_mgr.t("Settings", "RestartHint"))

    def quit_app(self):
        self._hk_manager.unregister_all()
        QApplication.instance().quit()

    def closeEvent(self, event):
        """点击关闭按钮 -> 隐藏到托盘"""
        event.ignore()
        self.hide()