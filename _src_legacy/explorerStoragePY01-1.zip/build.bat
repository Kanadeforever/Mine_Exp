@echo off
cd /d "%~dp0"

call venv\Scripts\activate.bat

pyinstaller --onefile --noconsole ^
    --name "ExplorerSessionSaver" ^
    --clean ^
    --add-data "language;language" ^
    --add-data "config.ini;." ^
    --add-data "app/resources;app/resources" ^
    main.py

if %ERRORLEVEL% equ 0 (
    echo.
    echo Build success! exe is at dist\ExplorerSessionSaver.exe
    echo.
    echo Creating Session directory in dist...
    if not exist "dist\Session" mkdir "dist\Session"
    echo.
    echo NOTE: The exe will use its own directory for Session/ and config.ini.
) else (
    echo.
    echo Build failed.
)

pause