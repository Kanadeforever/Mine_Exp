"""
common.py
项目公共工具函数，不依赖任何 app 内模块（避免循环导入）
"""

import sys
from pathlib import Path


def get_base_dir() -> Path:
    """获取程序所在目录（兼容脚本和 PyInstaller 打包）"""
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent