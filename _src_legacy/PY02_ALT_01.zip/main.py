"""
Explorer Session Saver
主入口：启动 AppCore（系统托盘 + 全局热键，无主窗口）
"""

import sys
from PyQt6.QtWidgets import QApplication
from app.logger import get_logger
from app.app_core import AppCore

# ── 启动 ──

def main():
    logger = get_logger(__name__)
    logger.info("=" * 60)
    logger.info("Application starting...")

    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)

    core = AppCore()

    logger.info("Application started, running event loop...")
    sys.exit(app.exec())


if __name__ == "__main__":
    main()