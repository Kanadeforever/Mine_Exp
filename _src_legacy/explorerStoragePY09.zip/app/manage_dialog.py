"""
manage_dialog.py
会话管理对话框（两级层级：会话组列表 → 会话组内窗口条目）

第一层（默认）：
  - 显示所有 JSON 会话组
  - 单击选中，双击进入
  - 恢复按钮：只允许单选恢复（恢复整个会话组）
  - 删除按钮：删除选中的 JSON 文件
  - 重命名按钮：启用

第二层（进入会话组后）：
  - 第一行显示 ".." 用于返回上一级
  - 其余行显示窗口路径
  - 恢复按钮：支持多选恢复（恢复选中的窗口条目）
  - 删除按钮：从 JSON 中移除选中的窗口条目
  - 重命名按钮：禁用
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QListWidget, QPushButton, QMessageBox, QInputDialog,
    QAbstractItemView, QListWidgetItem,
)
from PyQt6.QtCore import Qt, QDir
from PyQt6.QtGui import QKeySequence, QShortcut

from app.language_manager import LanguageManager
from app import session_manager as sm
from app.logger import get_logger

logger = get_logger(__name__)

# ─── 特殊角色常量 ─────────────────────────────────────
_ROLE_BACK = "__BACK__"   # 用于标识".."返回项


class ManageDialog(QDialog):
    def __init__(self, lang_mgr: LanguageManager, parent=None):
        super().__init__(parent)
        self._lm = lang_mgr
        self._sessions = []

        # ── 层级状态 ──
        self._level = 0              # 0 = 会话组列表, 1 = 会话组内部
        self._current_session_name = None   # 进入第二层时记录会话组名

        self.setWindowTitle(self._lm.t("ManageSessions", "Title"))
        self.setMinimumSize(520, 350)
        self.setup_ui()
        self.setup_shortcuts()
        self.refresh()

    # ───────────────────────── UI 构建 ────────────────────

    def setup_ui(self):
        layout = QVBoxLayout(self)

        # 提示标签
        self.hint_label = QLabel(self._lm.t("ManageSessions", "SelectHint"))
        layout.addWidget(self.hint_label)

        # 会话列表（支持多选）
        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        layout.addWidget(self.list_widget)

        # 按钮行
        btn_row = QHBoxLayout()

        self.restore_btn = QPushButton(self._lm.t("ManageSessions", "RestoreSelected"))
        self.restore_btn.clicked.connect(self.restore_selected)
        btn_row.addWidget(self.restore_btn)

        self.delete_btn = QPushButton(self._lm.t("ManageSessions", "DeleteBtn"))
        self.delete_btn.clicked.connect(self.delete_selected)
        btn_row.addWidget(self.delete_btn)

        self.rename_btn = QPushButton(self._lm.t("ManageSessions", "RenameBtn"))
        self.rename_btn.clicked.connect(self.rename_selected)
        btn_row.addWidget(self.rename_btn)

        open_folder_btn = QPushButton(self._lm.t("ManageSessions", "OpenFolderBtn"))
        open_folder_btn.clicked.connect(self.open_folder)
        btn_row.addWidget(open_folder_btn)

        btn_row.addStretch()

        refresh_btn = QPushButton(self._lm.t("ManageSessions", "RefreshBtn"))
        refresh_btn.clicked.connect(self.refresh)
        btn_row.addWidget(refresh_btn)

        close_btn = QPushButton(self._lm.t("ManageSessions", "CloseBtn"))
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(close_btn)

        layout.addLayout(btn_row)

        # 初始状态：第一层
        self._update_button_states()

    def _update_button_states(self):
        """根据当前层级更新按钮的启用/禁用状态"""
        if self._level == 0:
            # 第一层：重命名启用，恢复启用（仅单选）
            self.rename_btn.setEnabled(True)
        else:
            # 第二层：重命名禁用
            self.rename_btn.setEnabled(False)

    def setup_shortcuts(self):
        # Delete 键删除
        QShortcut(QKeySequence(Qt.Key.Key_Delete), self).activated.connect(
            self.delete_selected)
        # Enter / Return 恢复
        QShortcut(QKeySequence(Qt.Key.Key_Return), self).activated.connect(
            self.restore_selected)
        QShortcut(QKeySequence(Qt.Key.Key_Enter), self).activated.connect(
            self.restore_selected)
        # F2 重命名（仅第一层生效）
        QShortcut(QKeySequence(Qt.Key.Key_F2), self).activated.connect(
            self.rename_selected)
        # Ctrl+A 全选
        QShortcut(QKeySequence.StandardKey.SelectAll, self).activated.connect(
            self.list_widget.selectAll)
        # 双击
        self.list_widget.itemDoubleClicked.connect(self._on_double_click)

    # ───────────────────────── 数据加载 ────────────────────

    def _get_session_window_paths(self, name: str) -> list[str]:
        """获取会话内的窗口路径列表"""
        paths = []
        path = sm._session_path(name)
        if path.exists():
            try:
                data = __import__('json').loads(path.read_text("utf-8"))
                if isinstance(data, list):
                    for item in data:
                        p = item.get("Path", "")
                        if p:
                            paths.append(p)
            except Exception:
                pass
        return paths

    def _build_tooltip(self, name: str, count: int) -> str:
        """构建会话列表项的 tooltip（显示前 5 条窗口路径）"""
        paths = self._get_session_window_paths(name)
        lines = [f"会话: {name}", f"窗口数: {count}", ""]
        display = paths[:5]
        for p in display:
            lines.append(p)
        if len(paths) > 5:
            lines.append(f"... 还有 {len(paths) - 5} 个窗口")
        return "\n".join(lines)

    def refresh(self):
        """刷新列表（根据当前层级显示不同内容）"""
        self.list_widget.clear()

        if self._level == 0:
            # ── 第一层：显示会话组列表 ──
            self.setWindowTitle(self._lm.t("ManageSessions", "Title"))
            self.hint_label.setText(self._lm.t("ManageSessions", "SelectHint"))
            self._sessions = sm.list_sessions()
            for s in self._sessions:
                name = s['name']
                item = QListWidgetItem(f"{s['name']} | {s['count']} windows | {s['time_str']}")
                item.setData(Qt.ItemDataRole.UserRole, name)
                item.setToolTip(self._build_tooltip(name, s['count']))
                self.list_widget.addItem(item)
        else:
            # ── 第二层：显示会话组内的窗口条目 ──
            session_name = self._current_session_name or ""
            self.setWindowTitle(
                self._lm.t("ManageSessions", "Title") + f" — {session_name}")
            self.hint_label.setText(
                f"{self._lm.t('ManageSessions', 'SelectHint')} ({session_name})")

            # 添加 ".." 返回项
            back_item = QListWidgetItem("..")
            back_item.setData(Qt.ItemDataRole.UserRole, _ROLE_BACK)
            self.list_widget.addItem(back_item)

            # 添加窗口条目
            try:
                windows = sm.get_session_windows(session_name)
                for win in windows:
                    path_str = win.get("Path", "")
                    item = QListWidgetItem(path_str)
                    item.setData(Qt.ItemDataRole.UserRole, win["index"])
                    item.setToolTip(path_str)
                    self.list_widget.addItem(item)
            except sm.SessionError:
                pass

        self._update_button_states()

    # ───────────────────────── 选中项工具 ────────────────────

    def _get_selected_names(self) -> list[str]:
        """获取当前选中项的会话名列表（从 Qt.UserRole 读取，仅在 first level 有效）"""
        names = []
        for item in self.list_widget.selectedItems():
            name = item.data(Qt.ItemDataRole.UserRole)
            if name and isinstance(name, str) and name != _ROLE_BACK:
                names.append(name)
        return names

    def _get_selected_indices(self) -> list[int]:
        """获取当前选中项的窗口索引列表（仅在 second level 有效）"""
        indices = []
        for item in self.list_widget.selectedItems():
            data = item.data(Qt.ItemDataRole.UserRole)
            if isinstance(data, int):
                indices.append(data)
        return indices

    def _get_single_selected_name(self) -> str | None:
        """获取单选会话名；若未选或选多个返回 None"""
        names = self._get_selected_names()
        if len(names) == 1:
            return names[0]
        return None

    # ───────────────────────── 双击 ────────────────────

    def _on_double_click(self, item):
        """双击行为根据当前层级不同"""
        data = item.data(Qt.ItemDataRole.UserRole)

        if self._level == 0:
            # 第一层双击会话组 → 进入该会话组
            name = data if isinstance(data, str) and data != _ROLE_BACK else None
            if name:
                self._enter_session_group(name)
        else:
            # 第二层
            if data == _ROLE_BACK:
                # 双击 ".." → 返回第一层
                self._leave_session_group()
            elif isinstance(data, int):
                # 双击窗口条目 → 恢复该单个窗口
                self._restore_single_window(data)

    def _enter_session_group(self, name: str):
        """进入会话组"""
        self._level = 1
        self._current_session_name = name
        self.refresh()

    def _leave_session_group(self):
        """返回会话组列表"""
        self._level = 0
        self._current_session_name = None
        self.refresh()

    def _restore_single_window(self, index: int):
        """恢复单个窗口并关闭对话框"""
        name = self._current_session_name
        if not name:
            return
        self.accept()
        parent = self.parent()
        if parent and hasattr(parent, "restore_windows_by_indices"):
            parent.restore_windows_by_indices(name, [index])

    # ───────────────────────── 恢复 ────────────────────

    def restore_selected(self):
        """恢复选中项（不同层级行为不同）"""
        if self._level == 0:
            # ── 第一层：仅允许单选恢复整个会话组 ──
            names = self._get_selected_names()
            if not names:
                QMessageBox.information(
                    self, self._lm.t("ManageSessions", "RestoreTitle"),
                    self._lm.t("ManageSessions", "NoSelection"))
                return
            if len(names) > 1:
                QMessageBox.information(
                    self, self._lm.t("ManageSessions", "RestoreTitle"),
                    self._lm.t("ManageSessions", "SelectSingleSession"))
                return
            self.accept()
            parent = self.parent()
            if parent and hasattr(parent, "restore_session_by_name"):
                parent.restore_session_by_name(names[0])
            else:
                sm.restore_session(names[0])
        else:
            # ── 第二层：支持多选恢复窗口条目 ──
            indices = self._get_selected_indices()
            if not indices:
                QMessageBox.information(
                    self, self._lm.t("ManageSessions", "RestoreTitle"),
                    self._lm.t("ManageSessions", "NoSelection"))
                return
            name = self._current_session_name
            if not name:
                return
            self.accept()
            parent = self.parent()
            if parent and hasattr(parent, "restore_windows_by_indices"):
                parent.restore_windows_by_indices(name, indices)

    # ───────────────────────── 删除 ────────────────────

    def delete_selected(self):
        if self._level == 0:
            # ── 第一层：删除选中的会话组（JSON 文件） ──
            self._delete_selected_sessions()
        else:
            # ── 第二层：从 JSON 中移除选中的窗口条目 ──
            self._delete_selected_windows()

    def _delete_selected_sessions(self):
        """删除选中的会话文件"""
        names = self._get_selected_names()
        if not names:
            QMessageBox.information(
                self, self._lm.t("ManageSessions", "DeleteTitle"),
                self._lm.t("ManageSessions", "NoSelection"))
            return

        msg = self._lm.t("ManageSessions", "Confirm", names[0])
        if len(names) > 1:
            msg += f"\n({len(names)} items selected)"
        ret = QMessageBox.question(
            self, self._lm.t("ManageSessions", "ConfirmTitle"),
            msg,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if ret != QMessageBox.StandardButton.Yes:
            return

        ok_count = 0
        for name in names:
            if sm.delete_session(name):
                ok_count += 1
        logger.info("Deleted %d/%d sessions", ok_count, len(names))
        self.refresh()

    def _delete_selected_windows(self):
        """从当前会话组中移除选中的窗口条目"""
        indices = self._get_selected_indices()
        if not indices:
            QMessageBox.information(
                self, self._lm.t("ManageSessions", "DeleteTitle"),
                self._lm.t("ManageSessions", "NoSelection"))
            return

        session_name = self._current_session_name
        if not session_name:
            return

        msg = self._lm.t("ManageSessions", "ConfirmDeleteWindow", str(len(indices)))
        ret = QMessageBox.question(
            self, self._lm.t("ManageSessions", "ConfirmTitle"),
            msg,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if ret != QMessageBox.StandardButton.Yes:
            return

        # 从大到小排序以确保索引在删除过程中不变
        sorted_indices = sorted(indices, reverse=True)
        ok_count = 0
        for idx in sorted_indices:
            if sm.delete_window_from_session(session_name, idx):
                ok_count += 1
        logger.info("Removed %d/%d windows from session %s", ok_count, len(indices), session_name)
        self.refresh()

    # ───────────────────────── 重命名（仅第一层） ────────────

    def rename_selected(self):
        if self._level != 0:
            return  # 第二层禁用

        name = self._get_single_selected_name()
        if not name:
            QMessageBox.information(
                self, self._lm.t("ManageSessions", "RenameTitle"),
                self._lm.t("ManageSessions", "NoSelection"))
            return

        new_name, ok = QInputDialog.getText(
            self,
            self._lm.t("ManageSessions", "RenameTitle"),
            self._lm.t("ManageSessions", "RenameHint"),
            text=name,
        )
        if not ok or not new_name.strip():
            return
        new_name = new_name.strip()
        if new_name == name:
            return

        # 校验名称：禁止 Windows 文件名非法字符
        import re
        if not re.match(r'^[^/\\:*?"<>|]+$', new_name):
            QMessageBox.warning(
                self, self._lm.t("General", "Error"),
                self._lm.t("ManageSessions", "InvalidName"))
            return

        if sm.rename_session(name, new_name):
            logger.info("Session renamed: %s -> %s", name, new_name)
            self.refresh()
        else:
            QMessageBox.warning(
                self, self._lm.t("General", "Error"),
                f"Failed to rename session: {new_name} may already exist.")

    # ───────────────────────── 打开路径 ────────────────────

    def open_folder(self):
        """在资源管理器中打开会话存储目录"""
        import subprocess
        folder = str(sm.SESSION_DIR)
        subprocess.Popen(["explorer", folder])
        logger.info("Opened session folder: %s", folder)