"""
manage_dialog.py
会话管理对话框（列表、多选删除、恢复、重命名、打开文件夹）
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QListWidget, QPushButton, QMessageBox, QInputDialog,
    QAbstractItemView, QListWidgetItem,
)
from PyQt6.QtCore import Qt, QDir
from PyQt6.QtGui import QKeySequence, QShortcut

from app.language_manager import LanguageManager
from app import session_manager as sm
from app.logger import get_logger

logger = get_logger(__name__)


class ManageDialog(QDialog):
    def __init__(self, lang_mgr: LanguageManager, parent=None):
        super().__init__(parent)
        self._lm = lang_mgr
        self._sessions = []
        self.setWindowTitle(self._lm.t("ManageSessions", "Title"))
        self.setMinimumSize(520, 350)
        self.setup_ui()
        self.setup_shortcuts()
        self.refresh()

    def setup_ui(self):
        layout = QVBoxLayout(self)

        # 提示标签
        hint = QLabel(self._lm.t("ManageSessions", "SelectHint"))
        layout.addWidget(hint)

        # 会话列表（支持多选）
        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        layout.addWidget(self.list_widget)

        # 按钮行
        btn_row = QHBoxLayout()

        restore_btn = QPushButton(self._lm.t("ManageSessions", "RestoreSelected"))
        restore_btn.clicked.connect(self.restore_selected)
        btn_row.addWidget(restore_btn)

        delete_btn = QPushButton(self._lm.t("ManageSessions", "DeleteBtn"))
        delete_btn.clicked.connect(self.delete_selected)
        btn_row.addWidget(delete_btn)

        rename_btn = QPushButton(self._lm.t("ManageSessions", "RenameBtn"))
        rename_btn.clicked.connect(self.rename_selected)
        btn_row.addWidget(rename_btn)

        open_folder_btn = QPushButton(self._lm.t("ManageSessions", "OpenFolderBtn"))
        open_folder_btn.clicked.connect(self.open_folder)
        btn_row.addWidget(open_folder_btn)

        btn_row.addStretch()

        refresh_btn = QPushButton(self._lm.t("ManageSessions", "RefreshBtn"))
        refresh_btn.clicked.connect(self.refresh)
        btn_row.addWidget(refresh_btn)

        close_btn = QPushButton(self._lm.t("ManageSessions", "CloseBtn"))
        close_btn.clicked.connect(self.accept)
        btn_row.addWidget(close_btn)

        layout.addLayout(btn_row)

    def setup_shortcuts(self):
        # Delete 键删除
        QShortcut(QKeySequence(Qt.Key.Key_Delete), self).activated.connect(
            self.delete_selected)
        # Enter / Return 恢复
        QShortcut(QKeySequence(Qt.Key.Key_Return), self).activated.connect(
            self.restore_selected)
        QShortcut(QKeySequence(Qt.Key.Key_Enter), self).activated.connect(
            self.restore_selected)
        # F2 重命名
        QShortcut(QKeySequence(Qt.Key.Key_F2), self).activated.connect(
            self.rename_selected)
        # Ctrl+A 全选
        QShortcut(QKeySequence.StandardKey.SelectAll, self).activated.connect(
            self.list_widget.selectAll)

    def refresh(self):
        self.list_widget.clear()
        self._sessions = sm.list_sessions()
        for s in self._sessions:
            item = QListWidgetItem(f"{s['name']} | {s['count']} windows | {s['time_str']}")
            item.setData(Qt.ItemDataRole.UserRole, s['name'])
            self.list_widget.addItem(item)

    def _get_selected_names(self) -> list[str]:
        """获取当前选中项的会话名列表（从 Qt.UserRole 读取）"""
        names = []
        for item in self.list_widget.selectedItems():
            name = item.data(Qt.ItemDataRole.UserRole)
            if name:
                names.append(name)
        return names

    def _get_single_selected_name(self) -> str | None:
        """获取单选会话名；若未选或选多个返回 None"""
        names = self._get_selected_names()
        if len(names) == 1:
            return names[0]
        return None

    def delete_selected(self):
        names = self._get_selected_names()
        if not names:
            QMessageBox.information(
                self, self._lm.t("ManageSessions", "DeleteTitle"),
                self._lm.t("ManageSessions", "NoSelection"))
            return

        msg = self._lm.t("ManageSessions", "Confirm", names[0])
        if len(names) > 1:
            msg += f"\n({len(names)} items selected)"
        ret = QMessageBox.question(
            self, self._lm.t("ManageSessions", "ConfirmTitle"),
            msg,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if ret != QMessageBox.StandardButton.Yes:
            return

        ok_count = 0
        for name in names:
            if sm.delete_session(name):
                ok_count += 1
        logger.info("Deleted %d/%d sessions", ok_count, len(names))
        self.refresh()

    def restore_selected(self):
        names = self._get_selected_names()
        if not names:
            QMessageBox.information(
                self, self._lm.t("ManageSessions", "RestoreTitle"),
                self._lm.t("ManageSessions", "NoSelection"))
            return
        self.accept()
        # 通过 parent 的 restore_session 依次恢复
        parent = self.parent()
        if parent and hasattr(parent, "restore_session_by_name"):
            for name in names:
                parent.restore_session_by_name(name)
        else:
            # fallback：直接恢复第一个
            sm.restore_session(names[0])

    def rename_selected(self):
        name = self._get_single_selected_name()
        if not name:
            QMessageBox.information(
                self, self._lm.t("ManageSessions", "RenameTitle"),
                self._lm.t("ManageSessions", "NoSelection"))
            return

        new_name, ok = QInputDialog.getText(
            self,
            self._lm.t("ManageSessions", "RenameTitle"),
            self._lm.t("ManageSessions", "RenameHint"),
            text=name,
        )
        if not ok or not new_name.strip():
            return
        new_name = new_name.strip()
        if new_name == name:
            return

        # 校验名称格式（只能包含字母、数字、下划线、连字符）
        import re
        if not re.match(r'^[\w\-]+$', new_name):
            QMessageBox.warning(
                self, self._lm.t("General", "Error"),
                "Name can only contain letters, digits, underscore and hyphen.")
            return

        if sm.rename_session(name, new_name):
            logger.info("Session renamed: %s -> %s", name, new_name)
            self.refresh()
        else:
            QMessageBox.warning(
                self, self._lm.t("General", "Error"),
                f"Failed to rename session: {new_name} may already exist.")

    def open_folder(self):
        """在资源管理器中打开会话存储目录"""
        import subprocess
        folder = str(sm.SESSION_DIR)
        subprocess.Popen(["explorer", folder])
        logger.info("Opened session folder: %s", folder)