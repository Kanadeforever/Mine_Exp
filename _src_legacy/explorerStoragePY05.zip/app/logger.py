"""
logger.py
日志系统：输出到 BASE_DIR/logs/explorer-session-saver.log
"""

import logging
import sys
from pathlib import Path


def get_base_dir() -> Path:
    """获取程序所在目录（兼容脚本和 PyInstaller 打包）"""
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


LOG_DIR = get_base_dir() / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "explorer-session-saver.log"

# 日志格式
_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"
_DATE_FMT = "%Y-%m-%d %H:%M:%S"


def get_logger(name: str) -> logging.Logger:
    """
    获取（或创建）一个按模块命名的 Logger。
    所有 Logger 共享一个文件 Handler，避免重复写入。
    """
    logger = logging.getLogger(name)
    if logger.handlers:  # 已有 Handler，直接返回
        return logger

    logger.setLevel(logging.DEBUG)

    # 文件 Handler（追加模式）
    fh = logging.FileHandler(str(LOG_FILE), encoding="utf-8", mode="a")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(_FORMAT, _DATE_FMT))
    logger.addHandler(fh)

    # 控制台 Handler（仅在非打包模式输出）
    if not getattr(sys, 'frozen', False):
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(logging.Formatter(_FORMAT, _DATE_FMT))
        logger.addHandler(ch)

    return logger